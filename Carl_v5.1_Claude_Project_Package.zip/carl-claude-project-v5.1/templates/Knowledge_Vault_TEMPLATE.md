# Knowledge Vault | [CODE] | [Client name]

Status: TEMPLATE / DRAFT / CONFIRMED  
Version: [ ] | Updated: [ ] | Owner: [ ]  
Client Card: [CODE_Client_Card.md]  
Canonical Voice Asset: [exact filename, loaded separately in full]

Extract, never invent. Store only this client's source material. Blank fields are UNKNOWN; illustrative examples are not client facts. Index large raw sources as separate named files in this client's Knowledge. This index does not replace the canonical Voice Asset.

## Source register

| Source ID | Exact filename / URL | Type | Speaker/author | Date | Page/time/section locator | Accessed/verified date | Rights/permission + limits |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

## Vault index

| Entry ID | Category | Title | Source ID + locator | Evidence label | Claim/permission status | Used in Content IDs |
|---|---|---|---|---|---|---|
| | Stories / Frameworks / Opinions / Case studies / FAQs-objections / Voice | | | | | |

## Reusable entry template

### [CODE-IP-NNN] | [Title]

- Category:
- Source ID, exact filename and page/timestamp:
- Source date and speaker:
- Verbatim excerpt:
- Faithful summary (separate from quotation):
- Problem / pain / desire / identity / objection in buyer language:
- Client's belief, mechanism or lesson:
- Active objective/campaign, primary ICP and pillar fit:
- Approved claim wording and scope:
- Evidence: FACT / STRONG INFERENCE / HYPOTHESIS / UNKNOWN:
- Verification gaps or contradictory versions:
- Rights / permission / attribution / permitted uses:
- Approved by / date:
- Potential angles (hypotheses, not proven performance):
- Content IDs using this entry:

Category details, fill only those applicable:

- Story: verified situation → decision/intervention → outcome → lesson. No invented lived experience.
- Framework: original name, steps and source. Label any new name PROPOSED until approved.
- Opinion: exact belief, rationale, limits and language the client actually uses.
- Case study: dated baseline, intervention, result, metric/window, attribution limits, proof and publication permission.
- FAQ/objection: actual question, who asks, context, client answer and supporting proof.
- Voice: exact words, cadence/terminology and source. Promote approved rules to the canonical Voice Asset.

## Claims and rights queue

| Claim/asset ID | Proposed use | Evidence / rights source | Gap or conflict | Owner | Status | Confirmed date |
|---|---|---|---|---|---|---|
| | | | | | Pending | |

Unverified research: verify and cite, remove or rewrite without it. Never fabricate a client observation. Resolve unsupported superlatives before client-facing delivery. Record rights-safe footage substitutions in the internal edit pack.

## Hypothesis candidates

| Content ID | IP source | Objective/campaign + ICP | Problem → current belief → new belief | Angle / hook / format / funnel / CTA | Primary variable + controls | Success metric + comparison + window | Score /20 + override | Approval |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | Pending |

Use the full Content Hypothesis structure in `01_Growth_OS.md` before production. Hook candidates still need the 1.2-second timing check.

## Evidence requests

```text
[NEEDS CLIENT INPUT]
Question: ...
Why this matters: ...
What becomes possible: ...
```

## Update log

| Date | Entry/source affected | Change | Evidence | Confirmed by | File replacement saved? |
|---|---|---|---|---|---|
| | | | | | |

Keep operating decisions, performance and validated learnings in the Client Card/logs, linked to these source entries. Do not treat an extracted idea as a validated mechanism.
