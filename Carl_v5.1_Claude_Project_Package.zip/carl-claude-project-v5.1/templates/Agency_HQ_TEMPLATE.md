# Agency HQ | OKAK

Status: TEMPLATE / DRAFT / CONFIRMED  
Version: [ ] | Updated: [ ] | Owner: [ ]  
Project type: AGENCY HQ

Use only in the separate Agency HQ project. Keep the master template project empty of client data. HQ holds authorized agency operations summaries, agency economics and deliberately abstracted validated mechanisms. Raw client source material, voice, copy, stories, proof, confidential client data and unverified claims stay in their client projects. Operational client codes below identify routing/account status, not permission to import creative material.

## Agency objective and decisions

- Current agency objective, baseline, target and review date:
- Current constraint and evidence:
- Approved offers, scopes, prices and effective dates:
- Current acquisition priority and owner:

| Date | Decision | Reason | Evidence | Owner | Revisit |
|---|---|---|---|---|---|
| | | | | | |

## Roster and delivery

| Code | Client/project pointer | Pillars summary | Cadence | Assets queued | Assets live this week | Last review | Health | Owner | Renewal |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | UNKNOWN | | |

Health: green/on track, yellow/needs input, red/behind or blocked. Unknown evidence remains UNKNOWN. Record dated operator-supplied summaries; never imply automatic access to another project.

## Sales pipeline

| Prospect code | Stage | Qualification / disqualifier | Last confirmed interaction/date | Next action + timing | Owner | Evidence gaps | Exit condition |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Commercial messages and proposals remain drafts until authorized and actually sent. Store only authorized agency sales records here.

## Capacity and agency economics

| Period | Service/role | Available hours/units | Committed | Delivered | Revision/QC load | Constraint / hiring trigger |
|---|---|---|---|---|---|---|
| | | | | | | |

| Period | Agency revenue | Direct fulfillment cost | Gross margin | Retention | Capacity efficiency | Basis/source + limits |
|---|---|---|---|---|---|---|
| | | | | | | |

Report agency success separately from content success and account progress toward each North Star. Do not move these economics into client-facing reporting.

## Keyword Ledger

| Keyword | Client code | Magnet/destination | Platform | Routing namespace | Matching rules | Isolation verified + evidence | Live since | Status | Retired date/reason |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | Proposed | |

Check exact and near collisions against actual matching rules. Shared namespaces require unique live keywords. Isolated routing permits reuse only after verification. Record every use; keep retired history; immediately retire missing-resource keywords. For collisions record who keeps the word and the proposed replacement awaiting approval. Give each client project only its own current routing record and a sanitized collision-check result when needed.

## Promoted cross-client mechanisms

| Mechanism ID | Abstract mechanism | Evidence summary + comparable windows | Independent accounts/replications | Validity level | Confounders / limits | Approved by/date | Where applicable | Revisit / fatigue |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

Promotion gate:

1. Establish a VALIDATED CLIENT PATTERN with explicit repeated account evidence before promoting that account's learning into HQ. One post is only SIGNAL.
2. Abstract the mechanism. Remove client identifiers from learning examples, exact wording, stories, analogies, proof, confidential figures and CTA copy. Use authorized aggregate evidence summaries; keep underlying evidence in the originating project.
3. Record source lineage through operator-held pointers, maturity windows, comparison basis, controls/confounders, limits and approval. A pattern validated in one account is not yet CROSS-CLIENT PATTERN.
4. Use CROSS-CLIENT PATTERN only after comparable repetition across multiple clients and deliberate abstraction. State the evidence; do not invent a universal sample threshold.
5. Transfer a reviewed, sanitized mechanism note manually into relevant client Knowledge. No automatic project synchronization is assumed. Retest fit with that client's evidence and voice.

## Aggregate attribution and account-health actions

| Period | Qualified demand | Booked calls | Closed | Attributable / influenced revenue | Retention / expansion | Attribution limits + source |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

| Client code | Delivery | Creative | Data | Commercial | Relationship | Root cause / evidence | Next action | Owner / due |
|---|---|---|---|---|---|---|---|---|
| | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | | | |

## Operating review

- Daily: approvals, filming blockers, active conversations and urgent commercial work.
- Weekly: dated client summaries, winners/losses/surprises, explicit learnings and next tests.
- Monthly: results, attribution, retention, margin, capacity and approved decisions.
- Quarterly: objectives, offer, acquisition, fulfillment and expansion constraints.

## Transfer and update log

| Date | Record/mechanism | Source/destination project | Sanitization / allowed content | Approved by | Saved/uploaded confirmation |
|---|---|---|---|---|---|
| | | | | | |
