# Brand Constitution | [CODE] | [Client name]

Status: TEMPLATE / DRAFT / CONFIRMED  
Version: [ ] | Updated: [ ] | Approved by/date: [ ]  
Canonical Voice Asset: [this file OR exact separate filename, choose one]  
Client Card: [CODE_Client_Card.md]

Keep this client-specific file in the client's project only. If this is the canonical Voice Asset, load the entire file before scripting. If an approved external voice document is canonical, upload that document in full and point to it here and in the card. A summary is not a replacement. Unfilled fields are UNKNOWN.

## Positioning and audience

- One-line positioning:
- Differentiator and territories to own:
- Active objective/campaign and primary ICP (link to card):
- Audience level and vocabulary requiring a plain one-line explanation:
- Desired perception / perceptions to avoid:
- Proof boundaries and permitted claims (source IDs):

## Voice rules

| Dimension | Approved rule | Verbatim evidence + source locator |
|---|---|---|
| Tone and energy | | |
| Language and English/Hindi/Hinglish ratio | | |
| Address: tum / aap / you | | |
| Sentence length, rhythm and cadence | | |
| Terminology | | |
| Catchphrases | | |
| Swearing, slang and memes: yes/no + limits | | |
| Humor and emotional intensity | | |
| Preferred hook mechanisms | | |
| CTA style | | |

### Verbatim voice samples

Include enough approved source text to hear the actual voice; distinguish exact quotations from proposed copy.

| Sample ID | Exact words | Source/date/location | What this establishes |
|---|---|---|---|
| | | | |

### Forbidden

- Banned words and language patterns:
- Topics and sensitivities:
- Unsupported or prohibited claims:
- AI-style phrases and cadence to avoid:
- Examples that sound wrong, and why:

## Content rules

- Approved pillars and formats (link to card):
- Story use and approved story IDs:
- Hook mechanisms and fatigue (link to card):
- Approved CTA job/resource/keyword/routing (link to ledger):
- Reference adaptations permitted and excluded:
- Rules requiring correction because they conflict with Carl's hard constraints:

Viewer-first relevance, the hard 1.2-second hook and 7–10-second re-hook cadence apply regardless of brand preferences. Never authorize biography-first openings or another client's copy. Claims need evidence; outside footage needs confirmed rights.

## Visual rules

| Area | Approved standard / reference |
|---|---|
| Color palette | |
| Typography | Inter for document deliverables; specify approved video graphics/fonts here |
| Framing, locations, background, wardrobe | |
| Caption system and safe zones | |
| Cover system | |
| Pacing, transitions, graphics and sound | |
| Production standard: raw / polished + reason | |
| Owned/licensed footage sources and usage limits | |

Client-facing text uses no em dashes or italics. Client-facing analysis excludes tracking/reporting tool names. Shoot packs begin on scripts and exclude internal edit work; own-crew clients receive spoken lines only.

## Approvals

| Gate | Owner | Evidence of approval / date | Current status |
|---|---|---|---|
| Voice summary | | | Pending |
| ICP | | | Pending |
| Facts and claims | | | Pending |
| Script / strategy | | | Pending |
| Edit | | | Pending |
| Publish | | | Pending |

## Decision history

| Date | Decision | Reason | Evidence | Owner | Revisit |
|---|---|---|---|---|---|
| | | | | | |

After confirmation, align the Client Card's voice summary, canonical filename and approval dates. Keep one current approved version in Knowledge.
