# Client Card template

Create one copy per client. Replace CODE/XXX with a unique 2–4 letter code. Blank fields mean UNKNOWN; use written N/A with a reason where appropriate. Keep this complete card current. Link detailed Vault and Constitution records by exact filename; do not maintain conflicting copies of the same rule. No client facts are prefilled.

```text
========================================
CLIENT CARD — [Name] | CODE: [XXX]
Last updated: [date]
Status: TEMPLATE / DRAFT / CONFIRMED
Project type: CLIENT
Client/project boundary: [one client only]
Approved by / date: [pending]
Canonical Voice Asset filename: [CODE_Brand_Constitution.md or exact approved separate file]
Voice approval / date: [pending]
ICP approval / date: [pending]
Supporting files and versions: [exact filenames]
Content ID counter: [last assigned ID / next unused number]
Evidence status: FACT / STRONG INFERENCE / HYPOTHESIS / UNKNOWN
========================================
IDENTITY
  Name:
  Age (optional; only if relevant to positioning, story, audience relatability or compliance):
  Specific niche:
  One-line positioning:
  Differentiator:
  Personal story (verified beats only):
  Proof / credentials (source + date):

AUDIENCE
  Who exactly watches:
  Biggest pain solved:
  Language + ratio (English / Hindi / Hinglish):
  Level (beginner / intermediate / advanced):
  Aspirational identity:
  TOFU shareability audience (if relevant; who might they share with):

VOICE
  Tone:
  Address (tum / aap / you):
  Catchphrases (verbatim):
  Banned words:
  Cursing / slang / memes:
  Signature hook mechanism:
  Signature CTA style:

DATA
  Three best assets + verbatim opening lines + runtime in seconds + maturity window + why they won:
  Two weakest assets + maturity window + diagnosis:
  Winning mechanisms and validity level:
  Best-performing length:
  Content pillars (3–5) + target ratio:

BUSINESS
  Primary commercial objective for next 90 days (linked to North Star):
  Offer(s) / how money is made:
  Highest-ticket offer + price (source + date):
  Conversion path:
  Current followers + 30-day growth (source + date):
  Fulfillment capacity and constraints:

ENGAGEMENT SCOPE (what OKAK actually does for this client)
  Scope approved by / date:
  Deliverables in scope:
  Explicitly out of scope (client does it themselves):
  Tools we hold access to:
  Where our leverage sits, given what is out of scope:

OPS
  Posting cadence + time slots:
  Filming days:
  Editor:
  Approval chain:
  Non-negotiables and sensitivities:

90-DAY NORTH STAR
  Objective (one):
  Baseline (value, date, source):
  Target (value, date, source or [VERIFY]):
  Leading metric:
  Lagging / business metric:
  Offer or campaign connected:
  Constraints and capacity:
  Review date:
  Evidence status: FACT / STRONG INFERENCE / HYPOTHESIS / UNKNOWN

PERFORMANCE LOG (rolling)
  | Date | Content ID | Maturity window | Hook | Views | 3s hold | Saves | Shares | Profile actions | Commercial | Verdict |
  Learnings this month:
  Fatigued mechanisms:

--- OKAK GROWTH OS LAYER ---
CLIENT GROWTH BRIEF
  Business: sells __ | price __ | highest-ticket offer __ | sales mechanism __
            clients/month __ | revenue range __ | acquisition channels __
  Audience: who buys __ | who does not __ | geo __ | age (optional if relevant) __ | gender __
            income/business level __ | awareness level __
  Brand: known for __ | unique beliefs __ | topics to own __ | off-limits __
  Growth: primary objective __

PRIMARY CURRENT ICP (one per active growth objective / campaign)
  Active objective / campaign:
  Who / age (optional if relevant) / gender / location / occupation / income:
  Wants:
  Frustrations:
  Fears:
  Already tried:
  Believes:
  Misunderstands:
  Embarrassed to admit:
  Secretly wants:
  Why buy:
  Why not buy:
  Triggers / disqualifiers:
  Secondary inactive ICPs:

PAIN & DESIRE DATABASE (target 50–100)
  | # | Bucket | Surface statement | Level-2 | Level-3 content-ready | Evidence | Used in |

KNOWLEDGE VAULT INDEX
  Stories: | Frameworks: | Opinions: | Case studies: | FAQs / objections: | Voice:

PILLARS (territories, not one-word subjects)
  | Pillar | Problem / territory | Funnel stage | Target % | Evidence |

FUNNEL MIX (default starting 60 TOFU / 30 MOFU / 10 BOFU) — current: __/__/__
ITERATION MIX (default starting 70 proven / 20 modified / 10 experiments) — current: __/__/__

BRAND CONSTITUTION
  Voice rules: | Forbidden topics / phrasing / claims: | Visual rules:
  Content rules: | Approval chain:

HOOK MECHANISM LIBRARY
  | Mechanism | Hook / Content ID | Maturity window | 3s hold | Shares | Validity level | Fatigue |

ATTRIBUTION LEDGER
  | Content ID | Lead source | Content source | Qualified | Booked call | Closed | Revenue | Retention / expansion |

LEARNINGS LOG
  | Date | Observation | Evidence | Label | Hypothesis | Decision | Action | Result | Validity level |

DECISION LOG
  | Date | Decision | Reason | Evidence | Owner | Revisit |

FEEDBACK LOOP
  Why they chose us: | What they couldn't lose: | Most valuable result: | Where they heard about us:
========================================
```
