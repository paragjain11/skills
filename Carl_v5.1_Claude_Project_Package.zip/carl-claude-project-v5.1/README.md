# Carl v5.1 for Claude Projects

A modular conversion of the existing Carl v5.1 master prompt. The instruction field is about 1,470 words, down from the 11,850-word source. Detailed workflows remain in seven reference files. All four templates are blank; no client account data is included.

## What goes where

| File | Destination | Purpose |
|---|---|---|
| `00_Project_Instructions.md` | Paste into Project Instructions | Always-on priorities, evidence, scope, timing, voice isolation, approvals, command routing and modes |
| `knowledge/01_Growth_OS.md` | Project Knowledge | Strategy, ICP/pain/IP, hypotheses, scoring, pillars and funnel |
| `knowledge/02_Scripting_Production.md` | Project Knowledge | FAST/STANDARD/FULL details, two-document scripts, timing map, filming, edits, captions and reference adaptation |
| `knowledge/03_Performance_Learning.md` | Project Knowledge | Measurement, experiment validity, diagnosis, attribution and reviews |
| `knowledge/04_Commercial_SOPs.md` | Project Knowledge | Offer logic and all ten commercial command SOPs |
| `knowledge/05_Onboarding.md` | Project Knowledge | 44-question intake, mandatory fields and existing-client flow |
| `knowledge/06_Operations_Routing.md` | Project Knowledge | Roles, records, cadence, rollout, scope, keyword routing and boundaries |
| `knowledge/07_Command_Catalog.md` | Project Knowledge | Complete command syntax and actions |
| `templates/Client_Card_TEMPLATE.md` | Blank in master; completed copy in client Knowledge | Scope, North Star, ICP, evidence, approvals, performance and decisions |
| `templates/Brand_Constitution_TEMPLATE.md` | Blank in master; completed copy in client Knowledge | Voice, visual/content rules, proof limits and approvals |
| `templates/Knowledge_Vault_TEMPLATE.md` | Blank in master; completed copy in client Knowledge | Indexed sources, client IP, claims/rights and hypothesis candidates |
| `templates/Agency_HQ_TEMPLATE.md` | Blank in master; completed copy in HQ Knowledge | Agency operations, economics, routing, decisions and validated abstracted learnings |
| `README.md` | Operator setup guide; keep locally | Installation, naming, update process and preservation checks |

Instructions govern every task. Knowledge supplies the detailed method and current evidence for the relevant task. The small overlap on hard constraints is intentional: essential rules must not depend on retrieval of a long SOP. Do not paste the references or templates into the instruction field, or upload the original monolithic prompt alongside this package.

## Exact setup in Claude Projects

Use Claude's chat Projects at [claude.ai/projects](https://claude.ai/projects).

1. Click **+ New Project**. Enter the name and description. For Team/Enterprise, choose **Keep it private** unless broader access is intended.
2. Open **Set project instructions**. Paste the entire contents of `00_Project_Instructions.md`, append the appropriate binding below, then click **Save instructions**.
3. In the project Knowledge area on the right, click **+** and upload the individual Markdown files listed below. Unzip locally first; upload the `.md` files, not this zip.
4. Start a chat inside that project. Put identity in the instruction binding and confirmed card; Claude does not receive the project's name/description as instructions.

These interface steps were checked against [Anthropic's project setup guide](https://support.claude.com/en/articles/9519177-how-can-i-create-and-manage-projects) on 12 September 2026. Instructions apply across project chats, and uploaded Knowledge provides shared context. Keep confirmed files authoritative even when memory features are enabled.

### A. Clean master: `OKAK | Carl v5.1 | MASTER`

Append to instructions:

```text
Project type: MASTER TEMPLATE.
No active client. Maintain reusable rules and blank templates only.
Route client execution to its separate client project.
```

Upload all seven `knowledge/` files and all four blank `templates/` files. Keep this project unchanged by client onboarding, raw transcripts, analytics, scripts or proof. The master is a reusable source package, not a workspace for running every client.

### B. Agency HQ: `OKAK | Agency HQ`

Create a separate project using the same instructions and append:

```text
Project type: AGENCY HQ.
Use OKAK_Agency_HQ.md for authorized agency operations and sanitized learnings.
No client voice execution here. Keep client source materials in their client projects.
```

Upload all seven Knowledge references. Copy `Agency_HQ_TEMPLATE.md` to `OKAK_Agency_HQ.md`, fill only known agency records and upload it. Use `DAILY`, `ROSTER`, `QUALIFY`, `OFFER`, `HEALTH` or `LEARNINGS ALL` with the required supplied evidence. HQ does not automatically retrieve client projects.

### C. One client project: `OKAK | CODE | Client name`

Repeat for each client; choose a unique 2–4 letter code. Append this binding, replacing CODE and the name:

```text
Project type: CLIENT.
Active client: [Client name]. Client code: CODE.
Authoritative card: CODE_Client_Card.md.
Canonical Voice Asset: CODE_Brand_Constitution.md.
Use only this client's supplied evidence and Knowledge; ask if the binding conflicts with a file.
```

Upload all seven Knowledge references. Make and upload these three copies:

```text
CODE_Client_Card.md
CODE_Brand_Constitution.md
CODE_Knowledge_Vault.md
```

Use a completed onboarding form first if one exists. Confirm Engagement Scope before proposing work. Run `ONBOARD [Client name]` for a new client; for an existing client, supply the current card/form and request known-fact confirmation plus open questions. Confirm the North Star, primary ICP and voice. If an existing full voice document is canonical, upload it and change both the instruction binding and card to its exact filename.

Add only that client's raw source files, approved scripts, metrics and decisions. Do not also upload blank copies of its active templates, another client's card, or the completed HQ file. For a shared keyword namespace, supply the client's routing record plus a current sanitized HQ collision-check result before assigning a keyword.

## Naming and maintenance

| Record | Recommended filename |
|---|---|
| Current core files | `CODE_Client_Card.md`, `CODE_Brand_Constitution.md`, `CODE_Knowledge_Vault.md` |
| Raw source | `CODE_Source_YYYY-MM-DD_ShortTitle.md` |
| Separate canonical voice, if used | `CODE_Voice_Asset.md` |
| Large logs split out of the card | `CODE_Performance.md`, `CODE_Learnings.md`, `CODE_Decision_Log.md` |
| Routing snapshot | `CODE_Keyword_Routing.md` |
| One approved asset | `CODE-YYYY-NNN_Client_Shoot_Pack.md`, `CODE-YYYY-NNN_Internal_Edit_Pack.md` |
| Batch | `CODE_YYYY-MM-DD_Batch_Client_Shoot_Pack.md`, matching `Internal_Edit_Pack.md` |
| Sanitized mechanism note | `OKAK_Mechanism_NNN.md` |

Keep numeric prefixes on shared reference filenames so command routing resolves consistently. Folders organize this download; filenames identify uploaded Knowledge. Use Content IDs inside batch script/location labels. Keep internal metadata and completion footers out of the client shoot pack.

When Carl proposes a durable change, review it, confirm it, save the replacement Markdown, then replace the obsolete uploaded version. Keep one current version in Knowledge and dated archives locally. Carl must not claim it saved a project upload without actual execution or your confirmation. When logs grow, split them into the named files above and retain exact pointers in the card.

Agency-to-client learning transfers are manual and sanitized. Preserve evidence level and limits; a validated pattern in one account is not yet a cross-client pattern. Clients receive abstract mechanisms to test, never another client's wording, stories, proof or confidential data.

## First working commands

These are text commands interpreted by the prompt. They do not install integrations or perform external actions.

```text
ICP CODE
PAINBANK CODE 60
EXTRACT CODE
HYPOTHESIS CODE 10
BATCH CODE 8 STANDARD COLLAB
BATCH CODE 8 STANDARD EXECUTE
SCRIPT FULL CODE CODE-2026-001 EXECUTE
REVIEW CODE
MONTHLY CODE
```

Replace placeholders, supply source material for EXTRACT and comparable-window metrics for REVIEW. Use EXECUTE with approved context; FULL requires an approved asset. Publishing remains a human/connected-tool action.

IMPLEMENT retains the seven-day operating rollout. It is a target schedule, not permission to skip evidence, scope or approvals; new-client production follows the onboarding gates.

## Preservation and packaging notes

| Source behavior / v5.1 fix | Preserved in |
|---|---|
| Exact 1.2-second hook and 7–10-second re-hook wording | Project Instructions; onset invariant and final-tail example in 02 |
| Viewer-first story openings override conflicting voice guides | Instructions, 01 and 02 |
| Instruction/evidence hierarchies; FACT/inference/hypothesis/UNKNOWN; missing-input pattern | Instructions |
| Research, superlatives, rights and external-action integrity | Instructions, 02, 04 and templates |
| Engagement Scope, North Star, one ICP per objective/campaign | Instructions, 01 and complete Client Card |
| 44 questions; five mandatory fields; optional age; existing form reuse | 05; verbatim best openings and runtimes explicit in Client Card |
| FAST/STANDARD/FULL independent of COLLAB/EXECUTE; reuse approvals | Instructions, 02 and 07 |
| Full canonical voice loading and client firewall | Instructions, 02, 06 and Constitution |
| Two documents, scripts first, own-crew lines only, location grouping | Instructions and 02 |
| Keyword uniqueness scoped to routing namespace | Instructions, 06 and HQ template |
| Experiment variable/controls, maturity windows and validity levels | 01, 03 and Vault template |
| Content, Account and Agency success; agency economics only in HQ | Instructions, 03 and HQ template |
| Decision Log with owner and revisit | Client Card, Constitution, HQ and 06 |
| All command rows and ten commercial SOPs, offer ladder and pricing logic | 04 and 07 |

Packaging clarifications: the reference instruction to retain hook wording now explicitly yields to timing, viewer relevance, verified claims, rights and the voice firewall. Reference examples are not automatically proven or timing-approved. Metadata, voice checks and production notes are explicitly routed internally to preserve the shoot-pack boundary. The long startup speech becomes a brief idle greeting; direct requests run immediately. The footer uses a comma to respect the source's own no-em-dash house style. Core source examples using client names were replaced with generic CODE/ABC identifiers.

Provenance: workspace source `deliverables/carl-v5.1/Carl_v5_1.md`, identical to `carl-discord/brain/Carl_v5_1.md`. Source SHA-256: `ea966218fe9f11d4943862f12e5f518c06bd21535c8bb4e49bd01e181fc8dc3b`. Originals remain untouched. This is a reviewed Markdown conversion, not a Claude runtime test or an installed project.
