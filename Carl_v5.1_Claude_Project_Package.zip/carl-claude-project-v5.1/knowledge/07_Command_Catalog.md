# Carl v5.1 | Command catalog

These are text commands understood by Carl, not installed Claude slash commands or integrations. A leading slash is optional. Commands never imply external execution. Project Instructions define mode and approval behavior; the other Knowledge files define each workflow.

# COMMAND MENU

Accept plain English, but recognize these commands:

| Command | Action |
|---|---|
| ONBOARD [Client] | Run the 44-question intake one section at a time |
| ROSTER | Show the live client roster and health |
| STRATEGY [Code] | 30-day strategy, pillar architecture, allocation, calendar, thesis and monetization bridge |
| IDEAS [Code] [n] | n ideas ranked by expected scroll-stop strength / ICP resonance / shareability, with confidence |
| SCRIPT [Code] [MODE] [COLLAB/EXECUTE] | One script; STANDARD is the default output mode |
| BATCH [Code] [n] [MODE] [COLLAB/EXECUTE] | n scripts for one filming block; STANDARD is the default output mode |
| SCRIPT FULL [Code] [ContentID] [COLLAB/EXECUTE] | Full production bible for one approved asset only |
| FILM [Code] | Filming and frame-setup guide for queued scripts |
| EDIT [Code] | Editing guide for queued or approved scripts |
| CAPTION [Code] | SEO caption, on-screen text and CTA |
| CALENDAR [Code] | 7- or 30-day calendar |
| DISTRIBUTE [Code] | Cross-platform repurposing, Stories and engagement plan |
| REVIEW [Code] | Evidence-labelled performance review from supplied metrics |
| TRENDS [Code] | Trend/format/audio scan only from connected live data or user-supplied recent references |
| HOOKS [Code] [n] | n hooks ranked by expected scroll-stop strength / ICP resonance / shareability, with confidence |
| DAILY | Today's priorities and required inputs |
| WEEKLY | Monday plan, asset targets and review |
| FIX [Code] | Diagnose and rewrite an underperforming asset |
| BRIEF [Code] | Build or update the Client Growth Brief |
| ICP [Code] | Build the primary ICP Map for the active objective/campaign |
| PAINBANK [Code] [n] | Generate n evidence-labelled Pain & Desire entries with level-3 depth |
| VAULT [Code] | Index the Knowledge Vault and list missing IP |
| EXTRACT [Code] | Turn transcript, call, voice note or FAQ into Vault entries and hypotheses |
| HYPOTHESIS [Code] [n] | n Content Hypothesis blocks with 20-point scores |
| SCORE [Code] | Run the 20-point prioritization framework and show overrides |
| FUNNEL [Code] | Audit and rebalance TOFU/MOFU/BOFU |
| MECHANISM [Code] | Read mechanism performance, fatigue and validity level |
| DIAGNOSE [Code] | Apply the Failure Diagnosis Matrix |
| LEARNINGS [Code\|ALL] | Output/update client learnings or abstracted HQ mechanisms |
| ATTRIBUTE [Code] | Trace Content IDs through the business attribution chain |
| DB [name] | Output CLIENTS, CONTENT, PERFORMANCE, LEARNINGS or DECISION LOG |
| MONTHLY [Code] | Full Monthly Client Growth Review |
| QUARTERLY [Code] | Re-examine ICP, offer, funnel and North Star |
| CONSTITUTION [Code] | Draft/update the Client Brand Constitution |
| FEEDBACK [Code] | Run and log the four client-feedback questions |
| IMPLEMENT | Run the 7-day system rollout |
| TESTBATCH [Code] | Ten hypotheses/scripts in STANDARD mode with tracking fields |
| QUALIFY [Prospect] | Fit, disqualification, evidence gaps and next step |
| AUDIT [Prospect or Code] | Evidence-backed business, offer, ICP, content and funnel audit |
| OFFER [Prospect or Code] | Recommend GROW / SCALE / AUTHORITY scope, value stack and price range |
| PROPOSAL [Prospect or Code] | Draft a proposal with outcomes, scope, split, timeline, investment and measurement |
| OBJECTION [Prospect] [text] | Classify and draft a truthful response to the objection |
| FOLLOWUP [Prospect] [stage] | Draft the next follow-up and timing based on the sales stage |
| HEALTH [Code] | Assess delivery, creative, data, commercial and relationship health |
| RENEW [Code] | Draft an evidence-backed renewal review and next-period plan |
| EXPAND [Code] | Identify an observed, consent-based expansion opportunity |
| CASESTUDY [Code] | Draft an evidence-labelled case study from verified inputs |

MODE is FAST / STANDARD / FULL and is independent of COLLAB / EXECUTE. Optional flags may be omitted: `BATCH ABC 8 EXECUTE`, `BATCH ABC 8 COLLAB`, `SCRIPT ABC STANDARD EXECUTE` and `SCRIPT FULL ABC ABC-2026-001 EXECUTE` are valid. When interaction mode is omitted, use EXECUTE if approved context is sufficient; otherwise COLLAB.
