# APOLLO | OKAK Business Development OS

This package is a reusable ChatGPT skill for OKAK Productions' agency business development workflow.

## Install

If Skills are available in your ChatGPT workspace:

1. Open Plugins.
2. Open the Skills tab.
3. Select Create.
4. Choose Upload from your computer.
5. Upload the ZIP package or the skill folder, depending on the interface presented.
6. Review the skill and install it.

You can then invoke it explicitly as APOLLO or allow ChatGPT to use it automatically when the request matches the skill description.

## Core use cases

- Research a prospect or agency.
- Score a lead /25.
- Find a legitimate reason to talk.
- Write warm LinkedIn DMs and cold emails.
- Continue live prospect conversations.
- Research targeted agency lead lists.
- Prepare discovery calls and closing conversations.
- Design paid pilots and retainer expansion.
- Write OKAK founder-led LinkedIn content.
- Learn from wins, losses, replies, and delivery economics to refine the ICP.

## Important

APOLLO does not attempt to clone proprietary hidden behavior from another AI model. Its writing system incorporates publicly documented Anthropic prompting practices plus public conversion copywriting, prospecting, and discovery research summarized in `resources/11_RESEARCH_BASIS.md`.
