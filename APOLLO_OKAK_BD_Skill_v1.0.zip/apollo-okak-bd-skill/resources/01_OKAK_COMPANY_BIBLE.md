# OKAK Productions Company Bible

## Status
Canonical internal company knowledge for APOLLO.

## Company
OKAK Productions is a creative services and production company currently operating across three commercial divisions:

1. Personal Brand Growth
2. Embedded Post-Production
3. Developing Commercial Production

Primary commercial geographies include the UK, US, Canada, and Australia. Current outbound priority is UK marketing agencies.

## Division 1: Personal Brand Growth
Audience:
- high-ticket coaches
- experts
- mentors
- founders
- personal brands

Core proposition:
Turn expertise into a structured content growth system designed to build authority, reach the right audience, and create qualified demand.

The client remains the expert. OKAK builds and operates the content system around them.

Typical scope may include:
- audience intelligence
- positioning
- content architecture
- expertise extraction
- ideation
- scripting
- editing
- publishing strategy
- campaign planning
- analytics
- experimentation
- performance learning
- CTA strategy
- repurposing

Do not position this division as generic social media management.

## Division 2: OKAK Embedded Post
Current high-priority B2B offer.

Audience:
- marketing agencies
- performance agencies
- paid-social agencies
- social media agencies
- content agencies
- creative agencies
- personal-brand agencies
- production companies
- studios
- podcast studios
- other businesses with recurring video demand

Core proposition:
OKAK becomes the white-label post-production capacity behind another agency.

Primary problem solved:
The agency sells or manages more video work than its fixed internal post-production capacity can comfortably handle.

Core positioning:
- Your white-label post-production department when internal capacity gets stretched.
- Take on more video work without immediately adding permanent post-production headcount.
- Your client stays yours.
- The producer should not become our QC manager.

## Division 3: Commercial Production
Developing division.

Audience:
- brands
- advertising agencies
- creative agencies
- marketing agencies
- production partners

Direction:
Build OKAK into a credible commercial and branded-content production company capable of handling projects from brief through final delivery.

Potential scope:
- creative development
- pre-production
- crew assembly
- location production
- direction
- cinematography
- production management
- commercials
- branded content
- corporate films
- campaign content
- social campaigns
- post-production
- delivery

Do not imply large-scale production credits or experience that cannot be demonstrated.

## Core Capabilities
- video editing
- short-form editing
- long-form editing
- commercial editing
- corporate editing
- podcast editing
- multicam editing
- social cutdowns
- campaign cutdowns
- versioning
- subtitles
- motion graphics
- titles
- color grading
- sound design
- audio mixing
- basic green screen
- content repurposing
- platform adaptations

## Tools
Primary creative and workflow tools include:
- Adobe Premiere Pro
- DaVinci Resolve
- Adobe After Effects
- Frame.io
- Google Drive
- Dropbox where required

AI may be used as an internal efficiency layer. AI is not the commercial product.

## Team
Known current structure:
- 3 founders
- approximately 6 to 7 editors available through the current team/network

Do not present team size as a fixed full-time headcount unless verified for the specific use.

Production specialists may be assembled around projects when required.

## Desired Market Perception
OKAK should feel:
- reliable
- quietly competent
- commercially aware
- easy to work with
- responsive
- quality controlled
- tasteful
- scalable
- organized
- protective of the agency-client relationship
- low drama

The relationship should feel closer to embedded production infrastructure than external vendor chaos.

## White-Label Principles
When operating white-label:
- the agency owns the client relationship
- OKAK does not independently solicit the agency's end client
- confidential information remains confidential
- client IP is not reused across unrelated accounts
- confidential white-label work is not claimed publicly without permission
- non-circumvention is respected

Internal mantra:
YOUR CLIENT STAYS YOURS.

## Quality Control
The objective is to reduce the agency's management burden.

Desired flow:
Agency sends brief/assets -> OKAK executes -> OKAK reviews internally -> agency receives work that has already passed internal QC.

Applicable QC can include:
- brief adherence
- story/edit logic
- branding
- audio
- graphics
- spelling
- aspect ratio
- technical export
- continuity
- revision notes
- final delivery specs

Do not claim a formal certified process unless it is actually in operation.

## Delivery Philosophy
Time-zone leverage can be useful for UK and US agencies. Work can sometimes progress while the agency team is offline.

Do not blindly promise overnight, 24-hour, or 48-hour delivery. Turnaround depends on scope, duration, motion complexity, asset readiness, revisions, team availability, and output requirements.

## Primary Differentiators
- white-label confidentiality
- scalable capacity
- continuity of account knowledge
- internal QC
- workflow compatibility
- multi-format delivery
- time-zone leverage where useful
- lower management burden

## Portfolio
Existing completed work is stored primarily on Frame.io.

Portfolio should be curated by use case, not dumped into one undifferentiated gallery.

Potential categories:
- commercial
- personal brand
- podcast
- corporate
- long-form
- short-form
- social
- motion
- color
- sound
- campaign cutdowns
- event
- branded content

Respect white-label permissions.

## Proof Standard
Classify proof as:
- VERIFIED PROOF
- INTERNAL PROOF
- WHITE-LABEL CONFIDENTIAL
- UNVERIFIED CLAIM
- UNKNOWN

Never invent results, clients, project counts, team size, turnaround metrics, revenue impact, retention, production scale, awards, or certifications.

## Communication Standard
OKAK communication should be:
- human
- sharp
- competent
- understated
- commercially intelligent
- specific
- low pressure

Avoid generic agency jargon, fake urgency, overclaiming, and AI-sounding phrasing.

## Internal Systems
CARL:
Client intelligence, strategy, content operations, performance learning, and delivery intelligence.

APOLLO:
Business development, market intelligence, account research, relationships, pipeline, partnerships, and revenue growth.

Long-term loop:
APOLLO finds and closes suitable clients -> CARL learns from delivery -> delivery intelligence improves the ICP -> APOLLO targets better accounts.

## Strategic Principle
Company capabilities can be broad. Acquisition should be narrow.

For the current agency campaign, lead with:
- capacity
- reliability
- workflow
- QC
- white-label discipline
- commercial flexibility

Do not lead with a service list.
