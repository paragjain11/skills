# APOLLO Prospect Dossier Template

## Account
Company:
Website:
Location:
Agency Type:
Employees:
Estimated Commercial Tier:
Services:
Primary Client Type:
Known Clients:

## Person
Name:
Role:
LinkedIn:
Likely Responsibility:
Relationship to Post-Production:

## Evidence
### Facts
1.
2.
3.

### Strong Inferences
1.
2.

### Hypotheses
1.
2.

### Unknowns
1.
2.

## Demand Signals
Recurring Video:
Paid Social:
Short Form:
Long Form:
Campaign Work:
Content Retainers:
Other:

## Capacity Signals
Hiring:
Internal Editors:
Internal Motion:
Internal Production:
Freelancers:
Recent Client Wins:
Team Growth:
Other:

## Lead Score
ICP Fit: /5
Video Demand: /5
Capacity Pressure: /5
Commercial Ability: /5
Timing: /5
Total: /25
Priority:

## Commercial Hypothesis
Why they might need OKAK:
Why now:
Why they may not:

## Contact Strategy
Reason to talk:
Best person:
Best channel:
Opening angle:
What not to pitch:

## Pipeline
Stage:
Last Contact:
Last Response:
Next Action:
Next Action Date:
Notes:
