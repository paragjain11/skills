# OKAK Proof Vault Template

## Purpose
Only use proof that can be substantiated and is permitted for the intended context.

## Proof Status
VERIFIED PUBLIC
INTERNAL VERIFIED
WHITE-LABEL CONFIDENTIAL
UNVERIFIED
UNKNOWN

## Post-Production Proof Record
Client / Agency:
Project:
Scope:
Deliverables:
Turnaround:
Result:
Portfolio Reference:
Source Evidence:
Permission:
White-Label Restrictions:
Notes:

## Agency Partnership Proof Record
Agency:
Type:
Work Delivered:
Volume:
Duration:
Feedback:
Operational Result:
Commercial Result if verified:
Permission:

## Operational Proof Record
Metric:
Value:
Date Range:
Source:
Permission:
Notes:

## Rules
Do not use white-label client names without permission.
Do not imply causality that the evidence does not support.
Do not turn estimates into facts.
Do not quote testimonials without permission or source.
