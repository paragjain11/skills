# APOLLO Discovery and Close System

## Philosophy
Diagnosis before prescription.

The objective of discovery is not to run a checklist. It is to understand whether a meaningful capacity problem exists, what impact it creates, why it matters now, and how the buyer would evaluate a solution.

## Pre-Call Prep
Know:
- company and service mix
- contact role
- current trigger
- video demand
- internal creative structure if visible
- recent wins/hiring
- strongest hypothesis
- what remains unknown

## Opening
Set a clear, low-pressure frame.

Example territory:
"Rather than run you through a deck, I'd rather understand how you currently handle post when workload spikes. If there's a genuine fit, I can show you how we structure it. If not, we'll know pretty quickly."

## Discovery Sequence
### Situation
- What kind of video work is recurring today?
- What stays internal?
- What goes external?
- How is the post team structured?

### Pain
- What happens when several projects overlap?
- Where does delivery slow first?
- What work creates the most coordination?
- Where do revisions/QC consume producer time?

### Impact
- What does that friction affect?
- Deadlines?
- margin?
- producer time?
- client experience?
- ability to accept work?

### Critical Event
- Is there a current project, client win, hiring gap, launch, or workload change making this more relevant now?

### Decision
- What would make an external post partner genuinely useful?
- What would make you reject one immediately?
- Who else needs confidence in the workflow?

## Meeting Control
Good control does not mean dominating the conversation.

Control means:
- clear agenda
- good questions
- listening
- summarizing
- choosing the next thread deliberately
- not pitching early
- landing a concrete next step

## Diagnosis Summary
Before presenting OKAK, summarize what you heard.

Structure:
"What I'm hearing is [situation], which creates [friction/impact], especially when [trigger]. The gap is less [surface problem] and more [root operational issue]. Is that accurate?"

Get agreement or correction.

## Offer Transition
Only after diagnosis.

Example territory:
"That's exactly the layer we sit in. We're not trying to replace your internal team. We give you managed white-label post capacity when the workload exceeds what the core team should be carrying."

## Pilot Close
Preferred first close:
One paid live project.

Example territory:
"If you've got a brief coming up that represents the kind of overflow you're describing, I'd rather prove the workflow on that than sell you a retainer based on a deck."

## Objections
### We Already Have Editors
Explore whether they cover:
- normal volume
- peak volume
- specialist motion/color
- versioning
- time-sensitive work

If there is no overflow need, do not force the sale.

### We Use Freelancers
Explore:
- availability
- consistency
- QC
- management time
- account knowledge

If their system works perfectly, respect it.

### Too Expensive
Ask what they are comparing against.

Possible comparisons:
- one freelancer
- internal salary
- current vendor
- cheap outsourcing

Do not defend price before understanding the comparison.

### Not Now
Respect it.

Potential position:
backup capacity for ugly weeks.

### Why You?
Use operational differentiation, not hype.

Example territory:
"Plenty of people can cut a video. The useful bit is having a team that learns the account, QC's its own work, survives a busy week without disappearing, and doesn't turn your producer into another layer of project management."

## Pilot Scoping
Define:
- project
- deliverables
- formats
- length
- references
- assets
- brand rules
- turnaround
- feedback owner
- revisions
- motion/color/sound requirements
- technical specs
- price
- success criteria

## After the Pilot
Review:
- what worked
- what caused friction
- what work recurs
- volume
- variability
- what internal team wants to keep
- what should move outside

Then propose the smallest recurring structure that removes meaningful friction.

## Expansion
Potential ladder:
Overflow partner -> recurring overflow -> reserved capacity -> dedicated pod -> embedded department.

## Negotiation Principle
Trade, do not casually concede.

If scope, turnaround, revision volume, or price changes, identify what changes on the other side.

Do not discount simply because the buyer asks.
