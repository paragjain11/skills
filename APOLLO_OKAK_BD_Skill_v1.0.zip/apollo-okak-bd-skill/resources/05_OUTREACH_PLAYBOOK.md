# APOLLO Outreach Playbook

## Goal
Create real agency relationships that reveal whether a commercial fit exists.

## Sequence
### Stage 1: Open
Goal: earn a reply.

Use:
- specific signal
- relevant observation
- one worthwhile question

Do not lead with:
- full service list
- portfolio
- pricing
- calendar
- retainer

### Stage 2: Explore
When they reply, stay in the conversation.

Understand:
- how they currently handle post
- internal versus freelance model
- client workload
- what happens during volume spikes
- where QC lives
- what producers spend time managing

Do not immediately say "that's exactly what we do."

### Stage 3: Connect
When relevance is clear, connect OKAK lightly.

Example territory:
"The reason I asked is we sit on the overflow side of that problem."

### Stage 4: Value
Possible next steps:
- compare workflow
- assess a live brief
- paid pilot
- capacity discussion

Avoid large free tests unless strategically justified.

### Stage 5: Meeting
Move to a call when text is no longer the efficient medium.

Prefer natural language:
"This might be easier to unpack properly than through LinkedIn archaeology."

Avoid canned "discovery call" language.

### Stage 6: Pilot
Use one real live project.

Scope it properly.

### Stage 7: Expansion
After successful delivery, identify repeatable workload before proposing reserved capacity or a dedicated pod.

## First-Message Angles
### Hiring Signal
Question whether the hire reflects growth, replacement, or deliberate in-house expansion.

### Client Win
Ask how delivery capacity changes when new retainers land together.

### Paid-Social Agency
Ask how creative volume is handled as media spend scales.

### Social Agency
Ask what happens to post when multiple client calendars collide.

### Producer
Ask which part breaks first: timeline, feedback, QC, freelancer availability, or hands-on capacity.

### Creative Work
Ask an informed craft or workflow question, not "love your work."

### Podcast / Interview
Reference a specific operational or commercial idea and ask a follow-up that a peer would ask.

## Follow-Ups
Never send "just following up."

Useful follow-up types:
- new company signal
- second observation
- relevant industry thought
- callback to their answer
- specific useful resource
- low-pressure close loop

### Follow-Up 1
Add information or sharpen the original question.

### Follow-Up 2
Show why you asked, without dumping the whole pitch.

### Final Follow-Up
Close the loop gracefully and leave a clear future position as backup capacity if relevant.

## Multithreading
For strong accounts, contact more than one relevant person, but do not spam the company with identical copy.

Adapt:
- founder: economics and growth
- producer: workflow and bandwidth
- creative: quality and consistency
- ops: predictability and resource planning

## Email vs LinkedIn
LinkedIn:
- more conversational
- usually shorter
- easier to use a question-first opener

Email:
- can carry slightly more context
- subject line should be simple and specific
- one clear idea per email

## Subject Lines
Prefer 2-5 words when possible.

Useful sources:
- client/campaign name
- operational topic
- job/hiring signal
- specific project reference

Avoid clickbait.

## Exit Rules
Stop chasing when:
- clear no
- no relevant problem
- no commercial fit
- repeated non-response after a reasonable sequence
- timing is explicitly wrong

Move to nurture if the account is strategically strong but not ready.
