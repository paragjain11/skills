# APOLLO ICP and Lead Scoring

## Current Primary ICP
UK marketing agencies with recurring client video demand where demand can exceed flexible internal post-production capacity.

## Priority Subsegments
1. Performance marketing agencies
2. Paid-social agencies
3. Social media agencies
4. Content agencies
5. Creative marketing agencies
6. Personal-brand agencies
7. Growth agencies
8. Integrated marketing agencies

## Initial Size Band
Approximately 5 to 50 employees.

This is a working range, not a permanent law. Expand or narrow it as evidence accumulates.

## Ideal Characteristics
- established client roster
- recurring work
- meaningful client budgets
- video used repeatedly
- small or stretched post team
- freelancer-heavy delivery
- creative hiring
- new client wins
- fast content cadence
- performance creative requirements
- founder/leadership still involved operationally

## Disqualifiers / Lower Priority
- solo freelancer businesses
- inactive agencies
- SEO-only / email-only / web-only firms with minimal video
- very small local client base with weak budgets
- no meaningful recurring video demand
- huge self-sufficient post-production department with little external need
- pure price-shopping behavior

## Lead Score /25
### ICP Fit /5
5: exact priority segment, right size, right buyer profile
4: strong fit with minor gaps
3: plausible fit
2: weak fit
1: marginal
0: wrong market

### Video Demand /5
5: video central to delivery, high recurring volume
4: strong recurring video
3: meaningful but not dominant
2: occasional video
1: little evidence
0: none

### Capacity Pressure /5
5: multiple direct signals, such as hiring + new wins + freelancer use
4: strong signal
3: plausible pressure
2: limited evidence
1: no signal
0: evidence suggests no need

### Commercial Ability /5
5: strong clients, meaningful project values, established agency
4: good commercial profile
3: adequate
2: questionable budgets
1: very weak
0: noncommercial

### Timing / Trigger /5
5: immediate current trigger
4: recent strong trigger
3: moderate trigger
2: weak timing
1: generic fit only
0: no reason now

## Priority
21-25: A PRIORITY
17-20: B PRIORITY
13-16: WATCHLIST
Below 13: LOW PRIORITY

## Trigger Library
High-value triggers:
- editor hiring
- motion designer hiring
- content producer hiring
- producer hiring
- multiple client wins
- major new retainer
- new service launch
- paid-social expansion
- content/video service expansion
- high client ad volume
- frequent freelancer recruitment
- new office / market expansion
- team growth
- founder discussing delivery growth

## Buyer Roles
### Founder / MD
Care about:
- growth
- margin
- headcount
- ability to accept more work
- risk

### Operations
Care about:
- predictability
- capacity
- workflow
- resource planning

### Producer
Care about:
- deadlines
- feedback
- freelancer coordination
- QC
- bandwidth

### Creative Director
Care about:
- taste
- consistency
- creative control
- quality

### Head of Content
Care about:
- volume
- formats
- speed
- recurring delivery

## Research Standard
For each account try to establish:
- company
- agency subtype
- location
- verified size if available
- services
- client roster
- video demand
- internal editors/motion/production
- hiring
- recent wins
- growth signals
- buyer role
- current trigger
- reason to talk
- unknowns

Never infer pain merely from fit.
