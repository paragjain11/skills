# APOLLO Conversion Copy System

## Purpose
Use this module for website copy, service pages, landing pages, offer pages, pitch decks, proposals, case studies, lead magnets, sales collateral, and other conversion-oriented writing.

## Principle
Strategy before wordsmithing.

Do not start by trying to sound clever. Start by deciding:
- who this page is for
- what situation they are in
- what problem matters
- what they already believe
- what alternatives they use
- what outcome they want
- what proof exists
- what action the page should earn

## Research Inputs
Prioritize:
- customer interviews
- sales calls
- prospect replies
- testimonials
- reviews
- job descriptions
- support/revision notes
- competitor positioning
- public comments
- case studies
- website analytics when available

Extract:
- pains
- triggers
- desired outcomes
- objections
- alternatives
- words used repeatedly
- moments of highest frustration
- moments of highest desired relief/status

## Message Hierarchy
Before drafting, establish:

1. Audience
2. Current problem
3. Desired outcome
4. Why current alternatives fall short
5. OKAK mechanism / operating model
6. Proof
7. Risk reduction
8. CTA

## Headline Standard
A headline should usually communicate at least one of:
- who it is for
- desired outcome
- primary problem removed
- distinctive mechanism
- concrete operational advantage

Avoid vague lines such as:
- We tell stories
- Creative that moves people
- Elevate your brand
- Content that converts
- Ideas brought to life

## Embedded Post Website Example Territory
Weak:
"Powerful post-production for modern brands."

Stronger:
"Add white-label post-production capacity without adding permanent headcount."

Alternative:
"More client video. Less production chaos."

Use the line that best matches the page's awareness level and proof.

## Page Architecture
Typical service page:

1. Hero: problem/outcome + clear audience
2. Recognition: demonstrate understanding of current operating reality
3. Cost of the problem: what breaks when volume exceeds capacity
4. Mechanism: how Embedded Post works
5. Capabilities: only the services relevant to the buyer
6. Workflow: brief -> execution -> QC -> review -> delivery
7. Proof: work, testimonials, case studies, operational evidence
8. Risk reduction: paid pilot, white-label, non-circumvention, scoped workflow
9. Objections / FAQ
10. CTA

## Three-Pathway Homepage
OKAK's homepage can route visitors by job-to-be-done:

BUILD YOUR PERSONAL BRAND
For experts, founders, coaches, and mentors.

EXPAND YOUR DELIVERY CAPACITY
For marketing and creative agencies with recurring video demand.

PRODUCE THE CAMPAIGN
For brands and agencies requiring production execution.

The homepage should not explain all three businesses in one dense block. Let visitors self-identify quickly.

## Proof Placement
Place proof close to the claim it supports.

Examples:
- portfolio work near craft claims
- workflow evidence near reliability claims
- verified metrics near performance claims
- testimonials near relationship/experience claims

Never use impressive-looking numbers without context or verification.

## Case Study Structure
1. Context
2. Constraint/problem
3. Scope
4. What OKAK actually did
5. Workflow
6. Result, only where verified
7. What made the engagement work
8. Relevant next-step CTA

Do not invent commercial impact because the edit looked good.

## Proposal Copy
A proposal should feel like a diagnosis and operating plan, not a brochure.

Recommended order:
- what we heard
- problem / opportunity
- proposed operating model
- scope
- workflow
- roles/responsibilities
- timeline
- commercial terms
- assumptions / exclusions
- next step

## Offer Copy
Lead with the buyer's operational outcome.

For Embedded Post:
The agency is not buying "editing."
It is buying flexible capacity, continuity, QC, and lower management burden.

## CTA Design
Match CTA to buyer readiness.

Cold/early:
- See how Embedded Post works
- Compare workflows
- Run a pilot project

Higher intent:
- Send us a live brief
- Scope a pilot
- Discuss reserved capacity

Avoid generic "Get Started" if a more specific action exists.

## Editing Pass
After drafting:
- remove generic adjectives
- replace claims with evidence where possible
- replace abstract nouns with concrete operating language
- shorten repeated sections
- make every heading useful
- check that one primary message dominates each section
- remove em dash characters

## Quality Test
Ask:
- Could a competitor paste their logo into this page unchanged?
- Does the copy prove we understand the buyer's operating reality?
- Is the mechanism clear?
- Is the proof sufficient?
- Is the CTA appropriate to the visitor's commitment level?
- Does the page sound like OKAK rather than a generic agency?

If a competitor could use the same copy, it is not specific enough.
