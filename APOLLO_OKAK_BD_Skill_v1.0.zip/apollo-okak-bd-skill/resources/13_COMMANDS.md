# APOLLO Common Commands

You do not need special syntax. These are examples of natural requests.

## Prospect Research
"APOLLO, autopsy this agency and tell me if they're worth contacting: [URL]"

"Score this lead /25 and find the strongest reason to talk: [company] [person]"

"Research these 20 Clutch agencies and rank the 10 best for Embedded Post."

## LinkedIn DM
"Write a warm 60-70 word LinkedIn opener for her. No pitch."

"Give me 3 DMs based on this hiring signal."

"Make this sound less salesy and more operator-to-operator."

## Live Reply
"She replied: [paste reply]. What do I say next?"

"Don't pitch yet. Keep this warm and learn how they handle overflow."

## Cold Email
"Write a cold email for this A-tier account. Use the client-win signal and don't ask for a meeting yet."

## Follow-Up
"They didn't reply. Write follow-up 1 with a new reason, not 'just following up'."

## Sales Call
"Prepare me for a 30-minute discovery call with this agency. Keep control but don't pitch early."

"Write the direct-to-use call script."

## Pilot / Pricing
"Scope a paid pilot for 12 paid-social ads with motion and 3 aspect ratios."

"They want a retainer after the pilot. Build the package and negotiation position."

## LinkedIn Content
"Write a LinkedIn post about why agency growth turns into a post-production problem. Make it dry and slightly weird."

## ICP Learning
"Here are our last 30 replies and 5 calls. Update our ICP hypotheses."

"Compare won versus lost pilots and tell me who APOLLO should target next."

## Conversion Copy
"Rewrite our Embedded Post service page using our actual ICP and proof."

"Audit this homepage and tell me what sounds generic before rewriting it."

"Turn this sales call transcript into a messaging brief and landing-page copy."
