# APOLLO Research Basis

## Purpose
This file records the public research and prompt-design principles used to build APOLLO. It is not a substitute for current prospect research.

APOLLO does not attempt to copy proprietary hidden instructions or hidden reasoning from Claude or any other model. Instead, it incorporates public prompting guidance and public sales/copywriting research.

## 1. Anthropic Prompting Guidance
Source:
https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/prompt-templates-and-variables

Key principles incorporated:
- give clear, direct instructions
- provide context explaining why the behavior matters
- use examples to steer tone, structure, and edge-case behavior
- use structured sections/tags when prompts contain many kinds of context
- for long-context work, organize source material before the task and keep the final request clear
- explicitly specify output format and constraints
- use tool research when current external facts matter
- reflect on tool-result quality before proceeding
- avoid unnecessary overengineering

Application inside APOLLO:
- explicit operating modes
- clear evidence categories
- fixed response formats
- resource files separated by job-to-be-done
- few-shot examples for tone and judgment
- tool-use rules for current company research

## 2. Anthropic Business Prompt Engineering
Source:
https://www.anthropic.com/news/prompt-engineering-for-business-performance

Key principles incorporated:
- define the task precisely
- provide realistic examples
- combine prompt design with subject-matter expertise
- test and iterate instead of assuming a prompt is finished

Application inside APOLLO:
- the skill encodes OKAK's actual commercial context
- examples reflect real agency-sales situations
- ICP and copy should improve from live outcomes

## 3. OpenAI Skills Guidance
Sources:
https://openai.com/academy/skills/
https://help.openai.com/en/articles/20001066

Key principles incorporated:
- skills are reusable workflows, not giant one-off prompts
- use a SKILL.md playbook plus supporting resources
- define inputs, workflow, output format, and quality checks
- complex systems benefit from modular supporting resources

Application inside APOLLO:
- SKILL.md acts as router and operating system
- supporting resources contain company truth, offer, ICP, copy, outreach, discovery, proof, and examples

## 4. Gong Cold Email Research
Sources:
https://www.gong.io/files/gong-guide-how-to-master-cold-email-get-the-data-backed-guide-based-on-85-million-emails.pdf
https://www.gong.io/blog/does-cold-email-even-work-any-more-heres-what-the-data-says
https://www.gong.io/blog/cold-email-stats

Public findings incorporated:
- cold outreach should sell the conversation rather than force a meeting too early
- interest-based or low-friction asks can outperform direct meeting asks in cold contexts
- overly product-focused pitching can hurt replies
- concise emails should preserve enough context to be relevant
- top performers differ meaningfully from average outbound behavior

Application inside APOLLO:
- first messages normally avoid calendar asks
- first messages focus on relevance, curiosity, and one easy response
- APOLLO does not dump capabilities in the opener

## 5. 30 Minutes to President's Club
Sources:
https://www.30mpc.com/newsletter/how-to-personalize-cold-emails-at-scale
https://www.30mpc.com/newsletter/how-to-prioritize-your-cold-outreach-instead-of-cold-email-spray-and-pray
https://www.30mpc.com/newsletter/a-great-cold-email-and-what-makes-it-work

Public principles incorporated:
- personalize around business triggers, not random personal trivia
- rank company and person signals before writing
- prioritize trigger-based accounts and high-fit Tier 1 accounts
- use a trigger + problem hypothesis + concise relevance + low-friction CTA
- account selection is as important as copy quality

Application inside APOLLO:
- lead score separates fit, demand, capacity, commercial ability, and timing
- signals are researched before outreach
- personalization effort scales with account priority

## 6. Winning by Design
Sources:
https://winningbydesign.com/resources/blueprints/how-to-diagnose/
https://winningbydesign.com/resources/blueprints/the-perfect-discovery-call/
https://winningbydesign.com/resources/blueprints/the-spiced-framework/

Public principles incorporated:
- diagnosis precedes prescription
- understand situation, pain, impact, timing/critical events, and decision dynamics
- use fewer, better questions
- summarize to validate understanding before presenting a solution
- the buyer should articulate impact and urgency where possible

Application inside APOLLO:
- sales-call mode diagnoses before pitching Embedded Post
- objections are investigated rather than swatted away
- offer transition happens only after a confirmed diagnosis

## 7. Copyhackers and Voice of Customer
Sources:
https://copyhackers.com/ai-prompt/find-messaging-insights/
https://copyhackers.com/ai-prompt/use-ai-to-analyze-research/
https://copyhackers.com/2014/10/amazon-review-mining/
https://copyhackers.com/2022/03/messaging-strategy-101-how-to-think-first-then-write/
https://copyhackers.com/ai-prompt/write-a-cold-email-with-ai/

Public principles incorporated:
- gather voice-of-customer language before writing important conversion copy
- mine interviews, reviews, comments, surveys, and support material for pains, desires, objections, triggers, and alternatives
- strategy and message selection come before wordsmithing
- prospect research should be provided to the writing model explicitly
- AI-generated copy still requires human judgment and editing

Application inside APOLLO:
- prospect replies and calls become messaging intelligence
- the copy engine prioritizes buyer vocabulary
- APOLLO extracts recurring language instead of inventing generic pain copy

## 8. Synthesis Used by APOLLO
The research above is synthesized into the following operating rules:

1. Targeting quality comes before copy cleverness.
2. A real trigger beats decorative personalization.
3. First contact should earn a response, not force a meeting.
4. Diagnose before presenting a solution.
5. Use the buyer's language when evidence exists.
6. Separate facts from hypotheses.
7. Use humor only when it increases recognition or warmth.
8. A paid pilot is a credible bridge from conversation to recurring relationship.
9. Learn from actual wins, losses, replies, and delivery economics.
10. Copy quality is judged by commercial relevance, not how clever it sounds.
