# OKAK Embedded Post Offer Bible

## Offer Name
OKAK Embedded Post

Primary descriptor:
Your white-label post-production department.

Alternative descriptor:
Flexible white-label post-production capacity for growing agencies.

## Core Proposition
OKAK Embedded Post gives agencies reliable post-production capacity without requiring them to immediately increase permanent internal headcount.

The agency owns:
- client relationship
- strategy
- account management
- creative direction where applicable
- brand relationship
- commercial relationship

OKAK operates behind the scenes to execute post-production.

## Primary Buyer Problem
The problem is not simply "we need an editor."

The real problem is:
CLIENT VIDEO DEMAND CAN GROW FASTER THAN FIXED INTERNAL POST-PRODUCTION CAPACITY.

This can produce:
- missed deadlines
- freelancer coordination
- producer overload
- creative bottlenecks
- inconsistent quality
- excessive revisions
- overtime
- slow campaign iteration
- hiring pressure
- margin compression
- inability to accept more work

## Current Primary Buyer
UK marketing agencies with recurring client video demand.

Priority segments:
1. Performance marketing agencies
2. Paid-social agencies
3. Social media agencies
4. Content agencies
5. Creative marketing agencies
6. Growth agencies
7. Personal-brand agencies
8. Integrated marketing agencies

Potential secondary segments:
- production companies
- creative studios
- podcast studios
- in-house creative teams

## Ideal Account
Strong fit commonly includes:
- 5 to 50 employees initially
- established client roster
- recurring client work
- repeated video delivery
- meaningful client budgets
- small or stretched post team
- freelancer dependency
- creative hiring
- recent client wins
- periodic workload spikes
- continuous creative iteration
- producers/account teams coordinating too much execution

The ideal agency does not need OKAK every day. It needs confidence that flexible capacity exists when required.

## Primary Job to Be Done
Help the agency take on more video work without creating more production chaos.

Typical buyer language may sound like:
- we need overflow capacity
- we need reliable backup
- we need more ads produced
- we need versions and cutdowns handled
- we need editors without hiring right now
- we need less freelancer coordination
- we need a partner that learns our accounts
- we need post handled without producer babysitting

## Positioning
Primary:
YOUR WHITE-LABEL POST-PRODUCTION DEPARTMENT.

Supporting:
TAKE ON MORE VIDEO WORK WITHOUT ADDING PERMANENT POST-PRODUCTION HEADCOUNT.

Operational:
YOUR PRODUCER SHOULD NOT BECOME OUR QC MANAGER.

Relationship:
YOUR CLIENT STAYS YOURS.

Strategic:
CAPACITY SHOULD FLEX WITH WORKLOAD.

## What We Are Really Selling
Not editing hours.

We are selling:

CAPACITY
The agency can accept more work.

PREDICTABILITY
The agency knows where overflow can go.

RELIABILITY
A stable partner is available.

CONSISTENCY
Recurring accounts retain editorial knowledge.

QC
The agency should not receive obviously unfinished work.

LOWER MANAGEMENT BURDEN
Fewer fragmented resources to coordinate.

COMMERCIAL FLEXIBILITY
Capacity can grow without immediate permanent payroll.

WHITE-LABEL SECURITY
The agency-client relationship remains protected.

## Capabilities
Depending on scope:
- video editing
- short-form editing
- long-form editing
- paid-social creative editing
- social cutdowns
- podcast editing
- commercial editing
- corporate editing
- multicam editing
- campaign cutdowns
- versioning
- aspect-ratio adaptation
- subtitles
- titles
- motion graphics
- color grading
- sound design
- audio mixing
- basic green screen
- content repurposing
- final export preparation

## What It Is Not
Embedded Post is not:
- unlimited editing
- cheap offshore labor
- a random freelancer pool
- a marketplace
- an AI-generated editing service
- a replacement for every internal employee
- a promise that any project can be done overnight
- unlimited revisions

## Preferred Commercial Wedge
ONE PAID LIVE PROJECT.

Purpose:
Reduce risk and let both sides evaluate quality, communication, workflow, turnaround, brief interpretation, QC, revision handling, reliability, and cultural fit.

Prefer a real client brief over a meaningless hypothetical test.

## Ideal Pilot Types
- paid-social ad batch
- short-form batch
- podcast episode + cutdowns
- long-form edit
- campaign cutdowns
- client case study
- brand-film post
- social adaptations
- multiple aspect-ratio versions
- motion-supported content
- launch content
- corporate content

Best pilot: work the agency could realistically send again.

## Expansion Ladder
1. Paid Pilot
2. Overflow Partner
3. Recurring Overflow
4. Reserved Capacity
5. Dedicated Pod
6. Embedded Post Department

## Internal Pricing Architecture
Indicative anchors, not mandatory public packages:

Starter: approximately $2,500/month
Growth: approximately $5,000/month
Scale: approximately $10,000/month

Actual pricing depends on:
- volume
- scope
- project type
- duration
- motion requirements
- turnaround
- deliverables
- revision expectations
- team size
- producer/QC requirement
- workflow complexity
- commercial value

Do not force pricing into early outreach.

## Economic Frame
Potential alternatives include:
- hiring additional permanent editors
- managing multiple freelancers
- using expensive internal staff for coordination/QC
- turning down work due to capacity
- missing deadlines
- slowing campaign iteration

Do not claim universal cost savings. Understand the agency's current economics first.

## Why Not Just Hire?
Hiring can be right when demand is stable and predictable.

Embedded Post is more relevant when:
- demand fluctuates
- projects overlap
- multiple specialists are needed
- capacity is needed quickly
- the agency wants flexibility
- permanent hiring carries more risk

Do not attack hiring. Position a different capacity model.

## Why Not Just Use Freelancers?
Freelancers can be excellent.

Potential friction with fragmented freelance models:
- variable availability
- variable style
- variable communication
- scattered files
- knowledge loss
- producer coordination
- QC stays internal

OKAK should feel like a managed team relationship, not another isolated freelancer.

## Continuity
Where possible, recurring accounts should keep the same editor or pod.

Benefits:
- learns brand
- learns preferences
- learns pacing
- learns graphics
- learns feedback patterns
- learns stakeholders
- learns delivery expectations

Do not promise one exact individual forever. Promise continuity of account knowledge and managed handover.

## QC Principle
THE PRODUCER SHOULD NOT BECOME OUR QC MANAGER.

Applicable checks can include:
- brief adherence
- story structure
- branding
- spelling
- audio
- graphics
- aspect ratio
- frame issues
- revision notes
- export specs

The agency should focus on creative decisions, not preventable technical errors.

## White-Label Principle
The agency's client stays the agency's client.

OKAK should not:
- approach end clients independently
- expose agency margins
- claim confidential work publicly
- compromise the agency relationship

## Time-Zone Leverage
Potential UK workflow:
Agency hands off toward end of UK workday -> OKAK can continue progress during parts of UK off-hours -> agency returns to meaningful progress.

Do not overpromise overnight turnaround.

## Multi-Format Delivery
Modern agency work may require:
- hero asset
- 9:16
- 1:1
- 16:9
- cutdowns
- alternate hooks
- subtitles
- platform-specific versions
- campaign variations

This can be a major wedge for performance and social agencies.

## Segment Angles
### Performance / Paid Social
Pain: media buying can scale faster than creative production.

Positioning territory:
YOU RUN MEDIA. WE KEEP THE CREATIVE PIPELINE FED.

### Social Media Agency
Pain: every new client increases recurring content load.

Positioning territory:
YOU OWN THE CLIENT AND STRATEGY. WE PROVIDE THE POST CAPACITY UNDERNEATH IT.

### Content Agency
Pain: video becomes a growing share of content delivery.

### Creative Agency
Pain: the agency sells the campaign, then execution demand arrives.

### Personal Brand Agency
Pain: strategy may scale faster than fulfillment.

### Production Company
Pain: shoots create irregular post spikes.

## High-Value Buying Signals
- hiring editors
- hiring motion designers
- hiring producers
- hiring content staff
- recent client wins
- new retained accounts
- new paid-social service
- new video service
- high campaign volume
- heavy video advertising
- founder discussing growth
- small creative team
- frequent freelancer recruitment
- expansion

Signals guide questions. They do not prove pain.

## Discovery
Understand:
- how much video they deliver
- categories of work
- internal editor count
- freelance dependence
- what happens when projects overlap
- where post slows
- who reviews work
- producer time spent on QC
- easiest work to externalize
- work that must remain internal
- how often capacity becomes an issue
- what makes an external partner trustworthy

## Cold Outreach Principle
First contact should usually:
- reference a real signal
- show operator understanding
- ask one worthwhile question

Normally avoid:
- portfolio link
- pricing
- Calendly
- proposal
- service list
- retainer

## Primary Close
Not "sign a six-month retainer."

Preferred:
"Let's use one real project as the pilot."

The pilot must be paid, scoped, commercially sensible, and representative enough to prove capability.

## Pilot Success Criteria
Define before starting:
- scope
- deliverables
- timeline
- assets
- references
- brand rules
- communication channel
- feedback owner
- revision expectations
- specs
- price
- success criteria

## Post-Pilot Expansion
After delivery, review:
- what worked
- what could improve
- what work recurs
- frequency
- what monthly capacity would remove friction

Then design recurring capacity.

## Retainer Positioning
The retainer can buy:
- reserved capacity
- priority access
- stable team
- account knowledge
- QC
- predictable workflow
- faster handoff

## Commercial Boundaries
Avoid:
- unlimited work
- unlimited revisions
- undefined turnaround
- undefined scope
- free ongoing production
- premature discounting
- competing on price with low-cost freelancers
- guaranteeing outcomes outside OKAK's control

## Internal Mantra
MORE CLIENTS SHOULD NOT CREATE MORE PRODUCTION CHAOS.

YOUR CLIENT STAYS YOURS.

THE PRODUCER SHOULD NOT BECOME OUR QC MANAGER.

CAPACITY SHOULD FLEX WITH WORKLOAD.

PROVE IT ON A REAL BRIEF.

THEN BECOME DIFFICULT TO REPLACE.
