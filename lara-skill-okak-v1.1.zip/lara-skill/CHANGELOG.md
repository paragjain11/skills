# Changelog

## v1.1 - OKAK integration

- Added the full OKAK Offer Intelligence Master Reference PDF.
- Added an OKAK quick-reference knowledge file for fast retrieval.
- Added OKAK Mode to `SKILL.md`.
- Added current Personal Brand Demand Engine and Embedded Post offer routing.
- Added current pricing context and qualification logic.
- Added OKAK-specific first-touch outbound override: value/reason-to-talk first, no pitch or Calendly in message one.
- Added proof/confidentiality rules.
- Added APOLLO -> CARL handoff context.
- Updated README with the new knowledge files.
