# SMPV — Skill, Market, Problem, Value

## When to use
- User says: "I don't know what to post about"
- User says: "I'm not sure who I'm targeting"
- User says: "My content isn't converting"
- User says: "Help me position myself"
- Before writing any first post, calendar, or DM sequence

## The framework

**S — Skill.** What are you actually good at? Not your passion. Not your hobby. The skill other people pay you for, that you could do for 8 hours without burning out. Be ruthless here.

**M — Market.** Who specifically needs this skill? Be a sniper, not a shotgun. "Founders" is not a market. "B2B SaaS founders at $1M–$10M ARR selling to enterprise procurement teams" is a market. The narrower, the more leverage.

**P — Problem.** What burning problem do they have that your skill fixes? Name it in their language, not yours. Their words, not your jargon. "I'm drowning in DMs and none of them convert" beats "low lead-to-meeting conversion rate."

**V — Value.** What tangible outcome do you create by solving it? Quantify it. "Book 10+ qualified sales calls per month from organic LinkedIn content" beats "more leads and better conversions."

## The ChatGPT prompt Lara uses

```
Act as a market research analyst. I help [ideal client] get [result].

Analyze the LinkedIn landscape and broader online demand to identify:
1. Who specifically needs my services (target audience personas with demographics, job titles, pain points, goals)
2. What market segments are most attractive on LinkedIn (e.g., corporate wellness, founders, executives, remote workers, new parents)
3. What urgent problems they have that I can solve
4. How to position myself to be most appealing to them (messaging, offers, content themes)
```

Source: Lara's "$2.1M in 2026" video.

## Worked examples

### Example 1: Creator wanting to become an entrepreneur
- **Skill:** Writing + storytelling
- **Market:** Freelancers, coaches, entrepreneurs who can't write content that attracts
- **Problem:** "I'm not getting engagement / leads / followers"
- **Value:** Documented journey → frameworks → eventual services

### Example 2: Lara's own story
- **Skill:** Writing + storytelling on LinkedIn
- **Market:** Founders, freelancers, coaches who need to grow on LinkedIn
- **Problem:** "I can't get engagement or leads from LinkedIn"
- **Value:** Documented how she went from 0 to 320K followers and 7-figure business

### Example 3: AI-curious beginner
- **Skill:** Curiosity + ability to learn AI tools fast (e.g., Lovable, Claude, n8n)
- **Market:** Small agencies, solopreneurs, coaches who need automation
- **Problem:** "I don't have time / I'm drowning in manual work"
- **Value:** Free content showing the build → paid services for implementation

## How to apply

Before writing any post, DM, or calendar, run the SMPV check:

1. Does this asset ladder back to one of the 4 letters? If no, cut.
2. Does the hook name the Market and Problem specifically? If no, rewrite.
3. Does the CTA make the Value obvious? If no, sharpen.

## Common mistakes

- **S = too vague.** "Marketing" is not a skill. "LinkedIn ghostwriting for B2B SaaS founders" is a skill.
- **M = too broad.** "Everyone" is not a market. Pick one segment. You can expand later.
- **P = your language, not theirs.** Use the exact words your ICP uses in their posts and comments.
- **V = no number.** "More revenue" is a wish. "$50K/month from organic" is a value proposition.

## Anti-pattern: the lifestyle brand

If your SMPV is something like "lifestyle / motivation / hustle," Lara's view: that's not a skill, that's a personality. You can have personality, but it has to ladder back to a skill people pay for. Otherwise you're building an audience that doesn't convert.
