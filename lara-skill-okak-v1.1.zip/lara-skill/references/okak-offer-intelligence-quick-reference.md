# OKAK Offer Intelligence - Lara Quick Reference

Use this file whenever Lara is helping with OKAK Productions, an OKAK founder profile, OKAK LinkedIn content, OKAK outbound, or an OKAK prospect. The full internal source is `okak-offer-intelligence-master.pdf`.

## 1. Source-of-truth hierarchy

- **Canonical:** current decisions. Use by default unless the user explicitly overrides them later.
- **Working:** internal anchors, hypotheses, and operating rules. Use internally, but do not present them as public promises without context.
- **Verify:** proof, claims, credentials, testimonials, credits, permissions, and results that need evidence before public use.
- **Historical:** older pricing or prospect-specific proposals. Do not silently generalize them to new prospects.

Current superseding decisions:
- Personal Brand Demand Engine is currently **$4,000/month** as the standard flagship offer.
- Personal Brand now includes **DM automation setup**.
- Personal Brand is sold as a demand engine and operating system, not a bundle of editing deliverables.
- Embedded Post is the white-label agency-facing offer.
- Embedded Post internal anchors are **$2,500 / $5,000 / $10,000 per month**, but actual proposals are scoped.
- OKAK first-touch outbound must be warm and value/reason-to-talk first. Do not pitch in the first message.

## 2. Fast offer router

### Personal Brand Demand Engine
Route here when:
- The person is the expertise being marketed.
- They are an established coach, expert, mentor, consultant, educator, founder, or operator.
- They already have a proven offer/backend.
- Their bottleneck is positioning, expertise extraction, content consistency, buyer relevance, CTA/DM conversion, or qualified demand.

### OKAK Embedded Post
Route here when:
- The company sells video work to its own clients.
- It is a marketing, performance, social, content, personal-brand, creative/integrated agency, production company, or studio.
- Its bottleneck is overflow, recurring editing volume, freelancer inconsistency, specialist gaps, producer overload, turnaround pressure, or hiring pressure.
- Existing footage mainly needs editing, versioning, finishing, or scale.

### Separate path
If they need a shoot or commercial campaign production, use the separate Commercial Production path. Do not force it into either of these two offers.

## 3. Personal Brand Demand Engine

### Canonical positioning

**Core offer line:**
We build and operate your personal-brand growth engine, turning your expertise into a continuously tested content system designed to build authority, reach the right audience, and create qualified demand.

**Stronger commercial framing:**
We do not just help you create better content. We build the system that turns attention into structured conversations and qualified demand.

### Primary ICP

- Established coach, expert, mentor, consultant, educator, founder, or operator.
- Proven offer and real expertise.
- Business backend capable of selling and fulfilling demand.
- Usually high-ticket/high-value enough that a relatively small number of qualified conversations can justify a $4,000/month system.
- Already producing content, running interviews/podcasts, launching, advertising, or sitting on underused expertise.
- Able to record/provide footage, offer/funnel context, access, approvals, and timely feedback.

### Best buying triggers

- Has a course, coaching program, advisory offer, community, event, mentorship, or premium service that needs a stronger organic demand engine.
- Running ads and wants organic content to carry more trust and buyer education.
- Has long-form content, podcasts, presentations, interviews, or deep expertise with no systematic extraction/repackaging engine.
- Content gets attention but weak buyer-quality DMs, applications, calls, or enquiries.
- Positioning is diluted across too many themes.
- Preparing a launch.
- Founder/expert spends too much time ideating, scripting, editing, posting, and trying to understand performance.

### Weak fits

- No proven offer or monetization path.
- Wants guaranteed follower growth, virality, leads, or revenue.
- Only wants cheap editing or a fixed asset count with no strategic layer.
- Cannot give access to expertise, footage, approvals, or commercial context.

### Core problems

- Expertise is trapped in the expert's head or scattered across source material.
- Content is generic and not connected tightly enough to buyer pain or offer.
- Attention has no intentional next step.
- No structured CTA, DM, lead-capture, or qualification path.
- No learning loop connecting performance back into strategy.

### Desired result

- Stronger category authority.
- Better buyer relevance.
- Consistent content system.
- Structured conversations and qualified demand.
- Lower founder effort around the content machine.
- Measurable learning about what the market responds to.

### Mechanism

**Diagnose -> Extract -> Package -> Publish -> Trigger -> DM -> Qualify -> Learn -> Compound**

### Scope

OKAK operates:
- audience intelligence and positioning
- ICP/pain mapping
- offer/funnel mapping
- expertise/IP extraction
- content strategy and architecture
- scripting, hooks, rehooks, bodies, and CTAs
- editing and publishing strategy
- CTA architecture
- DM automation setup
- lead capture and routing
- analytics and experimentation
- performance learning
- attribution where measurable

Client supplies:
- expertise, stories, opinions, experiences
- raw footage/filming unless separately scoped
- offer, funnel, and backend context
- access to the expert
- timely approvals and feedback

### Expertise Extraction

Default working structure:
- 90-minute Strategic Interview Session
- 10-15-minute Hook + CTA Pickup Session

Extract:
- expertise
- stories
- frameworks
- contrarian opinions
- market observations
- objections
- proof
- offer/campaign material
- commercial insights
- new IP
- future content hypotheses

Interview architecture:
- 0-10: current reality
- 10-25: ICP pain
- 25-40: contrarian beliefs
- 40-55: stories
- 55-70: frameworks/IP
- 70-80: objections/buying questions
- 80-90: rapid fire
- +10-15: clean hooks and CTA pickups

### Content prioritization

Pre-production score /20:
- ICP specificity /4
- pain intensity /4
- novelty /4
- credibility /4
- commercial relevance /4

Decision rule:
- 14+ produce
- 11-13 rewrite
- 10 or below kill/rework

Experiment mix after a baseline exists:
- 70% proven concepts
- 20% variations
- 10% new experiments

### Metrics

Attention:
- reach
- watch time
- average watch time
- shares
- saves

Audience:
- profile visits
- follows
- audience quality

Demand:
- DMs
- lead magnet actions
- applications

Business:
- calls
- customers
- revenue attribution where measurable

Do not confuse strong creative metrics with business performance. Distinguish sourced pipeline from influenced pipeline where possible.

### Pricing

- Standard flagship: **$4,000/month**.
- Value is the system: strategy, expertise extraction, content, CTA/DM layer, analytics, experimentation, and reduced founder effort.
- Deliverable counts should live in the specific scope, not lead the positioning.
- Do not invent a minimum term if one has not been approved for that prospect.
- Existing bespoke deals may differ. Do not silently overwrite them.

### Personal Brand qualification score /25

Score 0-5 each:
- Offer maturity
- Expert authority/proof
- Content/audience foundation
- Demand economics
- Execution readiness

Interpretation:
- 21-25: strong fit
- 17-20: promising
- 13-16: diagnose/nurture
- below 13: likely weak fit unless a strategic reason exists

### Discovery questions

- What are you trying to make the personal brand do for the business over the next 6-12 months?
- What is the main offer, current price, and strongest customer profile?
- How are customers finding and buying from you today?
- What does the current content process look like from idea to published asset?
- Which content has produced the best conversations or customers, not just views?
- What do prospects consistently misunderstand, object to, or ask before buying?
- What source material already exists?
- What is currently automated in DMs, lead capture, email, application, or booking?
- What can you realistically commit to recording and approvals each month?

### Objection logic

**"We already have an editor."**
The gap may be strategy, extraction, CTA, distribution, measurement, or demand architecture rather than editing capacity.

**"Can you guarantee leads?"**
No. Clarify controllable inputs and which outcomes depend on offer, market, sales, and execution.

**"That is expensive."**
Ask what they are comparing it against: editing, SMM, paid acquisition, internal hire, or the economic value of qualified demand.

**"I do not have time to create content."**
Explain the extraction model: concentrated expert input, then OKAK operates the system around it.

**"Just give me viral videos."**
Reframe toward buyer relevance and business outcomes. Virality without relevance is not the objective.

### Sales language

One sentence:
**We build and operate the system that turns your expertise into consistent authority, qualified conversations, and measurable demand.**

Short:
**You stay focused on being the expert. OKAK extracts the IP, turns it into strategy-led content, builds the CTA and DM path, and uses performance data to make each cycle smarter.**

Commercial diagnosis:
**You may not need more content. You may need the content, audience, expertise, and offer you already have to start behaving like one commercial system.**

Primary CTA:
**Discuss your growth plan.**

## 4. OKAK Embedded Post

### Canonical positioning

**Core offer line:**
Your white-label post-production department when internal capacity gets stretched.

**Commercial outcome:**
Take on more video work without adding permanent post-production headcount.

Supporting lines:
- You sell the strategy. We handle the post-production behind it.
- Your client stays yours.
- Your producer should not become our QC manager.
- Capacity should flex with workload.

### Primary ICP

Organizations:
- performance marketing / paid-social agencies
- social media agencies
- content agencies
- personal-brand agencies
- creative/full-service/integrated agencies
- production companies
- studios

Immediate outbound priority:
- UK marketing agencies

Typical initial size:
- 5-50 employees
- recurring client video demand
- meaningful client budgets

Buyer roles:
- Founder / Co-Founder
- MD
- COO
- Operations Director
- Creative Director
- Head of Creative
- Head of Content
- Head of Production
- Senior Producer / Executive Producer

### High-signal buying triggers

- Hiring video editor, motion designer, content producer, creative producer, or post role.
- Recent client wins or new retained accounts.
- Team expansion.
- New or expanded video/content service.
- Heavy paid-social or high-volume short-form offering.
- Small post team relative to account/media/production workload.
- Frequent freelancer hiring.
- Founder/producer discussing scaling, capacity, or delivery pressure.
- Visible need for campaign versions, cutdowns, multi-platform adaptations, podcast, or long-form post.

### Weak fits

- No meaningful recurring video demand and no pilot-worthy current project.
- Primary need is full-service strategy, account management, or client acquisition rather than post.
- Requires advanced VFX/3D/specialist capability outside reliable scope unless separately resourced and agreed.
- Expects unlimited revisions, undefined rush capacity, or universal turnaround.
- Will not provide an adequate brief, assets, review owner, or consolidated feedback.
- Economics leave no room for a reliable outsourced partner.

### Problem map

Symptoms:
- producers editing or chasing freelancers
- inconsistent quality
- internal team always at capacity
- campaign launches create chaos
- urgent hiring cycles

Root causes:
- no clean separation of capacity and ownership
- no stable standards/QC layer
- fixed headcount cannot flex
- versioning exceeds normal workflow
- capacity is solved reactively

Commercial consequences:
- producer time lost to delivery management
- more revisions and weaker confidence
- agency declines work or over-hires
- margin compression
- wrong hires and idle capacity later

### Commercial ladder

**Paid Pilot -> Overflow Partner -> Recurring Overflow -> Reserved Capacity -> Dedicated Pod -> Embedded Post Department**

Paid Pilot must prove:
- quality
- communication
- turnaround within agreed scope
- workflow fit
- management burden reduction

### Capabilities

- short-form editing
- long-form editing
- commercial/corporate post
- podcast post
- multicam
- narrative/documentary-style editing where appropriate
- titles and lower thirds
- motion graphics
- campaign adaptations
- color correction/grading/finishing
- dialogue cleanup and sound design/mix within scope
- subtitles/captions
- cutdowns
- alternate hooks
- aspect ratios/social variants
- basic green-screen/routine compositing where reliable

### Pricing

Internal anchors:
- Starter: **$2,500/month**
- Growth: **$5,000/month**
- Scale: **$10,000/month**

Rules:
- Internal anchors are not universal public pricing.
- Per-project pricing is appropriate for pilots and irregular work.
- Actual proposal depends on volume, runtime, complexity, motion, color, sound, turnaround, revisions, concurrency, account knowledge, and team configuration.
- Retainers should buy predictable access/capacity and operating continuity, not an undefined promise of unlimited output.

### Agency lead score /25

Score 0-5 each:
- ICP fit
- Video demand
- Capacity pressure
- Commercial ability
- Timing / trigger

Interpretation:
- 21-25: A priority
- 17-20: B priority
- 13-16: watchlist / needs more evidence
- below 13: low priority

### First-touch outbound rule

Do not pitch or sell in the first message.

Structure:
**Specific signal + operator-level observation + worthwhile question**

Do not include:
- pricing
- Calendly
- portfolio
- proposal
- service dump
- generic "we help agencies scale" language

Default LinkedIn first message:
- about 45-80 words
- can be shorter when a compact message is stronger

When useful, output exactly:
1. Warm
2. Operator
3. Creative / slightly weird

Then choose **BEST PICK** with a concise reason.

### Follow-up rules

Every follow-up must add something new:
- observation
- idea
- relevant trigger
- piece of value

Banned stale language:
- just bumping this
- in case this got buried
- following up on my previous email/message
- circling back
- touching base

### Discovery questions

- How much video moves through the team in a normal month vs a peak month?
- What does the current post team look like: employees, freelancers, mixed?
- Where does the producer/account team spend time they should not be spending?
- Which deliverables create the most friction?
- What happens when several client projects overlap?
- How do briefs, reviews, and revisions move today?
- What would make an external partner easier than another freelancer?
- What would a successful paid pilot need to prove?

### Objection logic

**"Too expensive."**
Ask what they are comparing against: freelancer cost, internal salary, lost margin, missed client work, producer time, or another vendor.

**"We have editors."**
Explore normal vs peak capacity and specialist gaps. The offer is flexible capacity, not replacement for a healthy internal team.

**"We use freelancers."**
Explore consistency, availability, QC, management load, account knowledge, and continuity.

**"No need right now."**
Respect it. Position OKAK as backup capacity or nurture around future triggers.

**"Can you do 24-hour turnaround?"**
Ask about scope, runtime, complexity, assets, feedback timing, and current capacity. Never make a blanket promise.

### Paid pilot design

- Use a real client brief with normal expectations.
- Do not use artificial free tests that do not resemble actual workflow.
- Agree source assets, deliverables, specs, references, deadline, revision rounds, review owner, and handoff format before starting.
- Define success criteria before delivery.
- After completion, review quality, communication, turnaround, feedback friction, internal management effort, and what should change next time.

Primary CTA:
**Discuss post capacity.**

Supporting CTA:
**Share a project brief / inspect relevant work.**

## 5. APOLLO -> CARL handoff

### APOLLO
Owns:
- research
- qualification
- relationship building
- need diagnosis
- pipeline
- offer routing
- commercial advancement

Pipeline stages:
- RESEARCHED
- CONTACTED
- REPLIED
- CONVERSATION
- QUALIFIED
- MEETING
- PILOT OPPORTUNITY
- PILOT ACTIVE
- PILOT WON
- RETAINER OPPORTUNITY
- RETAINER WON
- NURTURE
- CLOSED LOST

### CARL
Owns:
- onboarding
- client knowledge capture
- delivery operations
- bottleneck diagnosis
- outputs
- performance measurement
- learning storage
- renewal
- expansion

Operating rule:
**APOLLO finds and qualifies the right relationship. CARL turns the promise into a repeatable operating system.**

Preserve the commercial diagnosis during handoff so CARL operates against what was actually sold.

## 6. How Lara should use this knowledge

### For OKAK founder content

Apply Lara's SMPV separately to each offer.

Personal Brand:
- Skill: strategy + expertise extraction + content system + CTA/DM + performance learning
- Market: established high-ticket experts/coaches/founders
- Problem: expertise/content is not becoming consistent qualified demand
- Value: authority + structured conversations + measurable demand

Embedded Post:
- Skill: managed white-label post-production capacity
- Market: agencies, production houses, studios
- Problem: video demand exceeds flexible internal capacity
- Value: take on more work without immediately adding permanent headcount or producer management chaos

### For the 4-3-2-1 system

Choose **one OKAK commercial topic per week**. Do not make every post sell both offers.

If Embedded Post is the week's priority:
- Educate on capacity economics, workflow, QC, versioning, hiring vs flex capacity, producer time.
- Document operating lessons, delivery systems, QC process, workload patterns, or anonymized workflow improvements when verified.
- Storytell founder/operator lessons that bridge back to reliability and delivery.
- Sell using a relevant case, pilot logic, capacity diagnosis, or a specific agency problem.

If Personal Brand is the week's priority:
- Educate on expertise extraction, positioning, buyer relevance, CTA/DM architecture, attribution, and learning loops.
- Document experiments and verified lessons from client work without leaking confidential details.
- Storytell founder lessons that bridge to authority, clarity, and demand.
- Sell through the problem diagnosis and the Personal Brand Demand Engine, not through asset counts.

### For DMs

In OKAK Mode, the first-touch rule above overrides Lara's generic cold-DM call CTA. The first message is for rapport and diagnosis, not booking a call.

### For proof

Never turn a creative metric into a business result. Never infer a direct client relationship from a recognizable brand in a project. Never expose white-label relationships without permission.
