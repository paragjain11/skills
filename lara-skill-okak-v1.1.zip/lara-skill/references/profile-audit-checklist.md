# LinkedIn Profile Audit Checklist

## When to use
- User asks: "Can you audit my LinkedIn profile?"
- User says: "My profile isn't converting"
- User says: "I'm not getting inbound leads"
- Before recommending any content strategy

## The 5-second test

Before auditing section by section, run the 5-second test:

1. Look at the profile picture. Does it look like a real person you'd want to talk to?
2. Read the headline. Do you know what they do, who they do it for, and what outcome they deliver?
3. Scan the banner. Does it reinforce the headline or is it generic stock art?

If any of those fail, the rest of the profile doesn't matter. People don't read past the first impression.

## Section-by-section audit

### 1. Profile photo
**Lara's rule:** A real photo of you, ideally in a context that signals your work. Stage, podcast, behind-the-scenes, with clients. Not a corporate headshot from 2019. Not a selfie in a car. Not AI-generated.

**Why:** "LinkedIn is not just the writing, it's the packaging. The photo needs to be good enough for someone to want to read what you have." Lara's own photos show her on stage, with her team, at events. Recognizable, contextual, real.

**Score:**
- ✅ Recognizable, contextual, recent
- ⚠️ Real photo but generic or dated
- ❌ Stock photo / AI face / no photo / group photo where they're hard to spot

### 2. Banner
**Lara's rule:** Custom graphic with one clear message. Often: your offer, your proof, or a question that hooks the right reader.

**Examples of good banners:**
- "I help B2B SaaS founders book 10+ calls/mo from LinkedIn. DM me 'GROWTH'."
- "From 0 to 320K LinkedIn followers. Building a 7-figure business in public."
- "Free 7-Day Personal Brand Course → [link]"

**Score:**
- ✅ Custom, message-clear, points to offer or proof
- ⚠️ Custom but vague ("Helping businesses grow")
- ❌ Stock photo / default blue / LinkedIn conference banner / nothing

### 3. Headline
**Lara's rule:** Three elements in 220 characters.
- **Who you serve** (the market)
- **What you do** (the skill)
- **What outcome you deliver** (the value)

**Examples:**
- Weak: "Founder | Speaker | Investor" (no market, no outcome)
- Weak: "Helping businesses grow through digital marketing" (no market specificity)
- Strong: "I help B2B SaaS founders book 10+ qualified sales calls/mo from LinkedIn content"
- Strong: "Writing content that turns strangers into paying customers | 320K followers | Forbes 30u30"

**Score:**
- ✅ Market + skill + outcome, specific, scannable
- ⚠️ Two of three elements, vague on market
- ❌ Job title only / buzzwords / "Open to work"

### 4. About section
**Lara's rule:** Open with the ICP's problem, not your bio. End with a CTA.

**Structure that works:**
1. **Line 1:** Acknowledge the reader's pain. "You're posting every day and getting nothing. Sound familiar?"
2. **Lines 2-4:** Why this happens. The mechanism, not the symptom.
3. **Lines 5-8:** What you do differently. Your framework, named.
4. **Lines 9-10:** Proof. Numbers, clients, results.
5. **Line 11:** CTA. "DM me 'GROWTH' to get the [resource]."

**Tone:** First person, conversational, no corporate speak. Read it aloud — if it sounds like a press release, rewrite.

**Score:**
- ✅ ICP pain → mechanism → framework → proof → CTA
- ⚠️ Has some elements but buries the CTA or skips the pain
- ❌ Career bio starting with "I am a passionate…" / no CTA / generic

### 5. Featured section
**Lara's rule:** Pin your highest-converting content + your best lead magnet. Not random posts.

**What to pin:**
1. Your top lead magnet post (the giveaway post)
2. Your best-performing post (the one that brought the most inbound)
3. A media feature or notable result (if you have one)
4. A link to your best free resource (newsletter, course entry)

**What to remove:**
- Old posts that don't represent your current offer
- Generic "excited to announce" posts
- Empty featured slots

### 6. Experience
**Lara's rule:** Treat this like a sales page for your current offer, not a CV.

**For your current role:** Rewrite the description as a value-prop for the ICP. "I help [market] get [outcome] through [method]. Currently working with [proof: number of clients / case study]."

**For past roles:** Compress. One line each. Years + title + one outcome.

### 7. Skills & Endorsements
**Lara's rule:** Top 3 skills should match your SMPV market and method. Endorsements don't matter much; the listing does.

### 8. Recommendations
**Lara's rule:** Get 3-5 from clients, not peers. The recommendation should describe the outcome the client got, not how nice you are.

**Template to send a happy client:**
"Hey [name], I'm refreshing my LinkedIn profile. Would you be open to writing a short recommendation focusing on the outcome you got from working with me? Even 3-4 sentences helps a lot. Happy to return the favor."

### 9. Activity & Engagement
**Lara's rule:** The audit isn't just the profile — it's the activity around it.

- **Posting frequency:** Last 30 days, how many posts? Less than 4 = signal of inconsistency.
- **Commenting frequency:** Are you commenting on 5-10 posts/week in your niche? If not, you're invisible.
- **Engagement quality:** Are your recent posts getting comments back, or just likes? Comments > likes.

## The SMPV profile check

After auditing section by section, run the SMPV lens:

- **Skill:** Does the profile make your skill obvious in 5 seconds?
- **Market:** Does the headline name a specific market, not "everyone"?
- **Problem:** Does the about section name the ICP's problem in their language?
- **Value:** Does the profile end with a clear outcome the reader can get from you?

If any of the four letters is missing from the profile, the rest of your content strategy is leaking. Fix the profile before scaling the content.

## The IFP check

The profile must appeal to both:
- **ICP (buyer):** Clear what you sell, clear what outcome, clear CTA.
- **IFP (follower):** Personable enough that someone who isn't ready to buy still follows and shares.

If your profile reads like a corporate brochure, you're losing the IFP. If it reads like a personal diary, you're losing the ICP. The balance is: clear offer + clear human.

## Common profile mistakes

1. **Headline = job title.** "Marketing Manager at X" tells the reader nothing about what you can do for them.
2. **About = CV.** Listing every job since 2015 instead of framing your current offer.
3. **Banner = default.** LinkedIn's blue banner is a wasted opportunity.
4. **Featured = empty.** Or filled with old posts that don't represent your current offer.
5. **Photo = group / selfie / corporate headshot.** Anything that makes you hard to recognize.
6. **No CTA.** The reader doesn't know what to do next. Always end with a specific action.
7. **No proof.** No numbers, no clients, no screenshots, no case studies. Without proof, you're just another person with a headline.

## The fix-this list

When delivering an audit, output a punchy prioritized list, not a 10-page report:

1. **Critical (fix today):** Photo, headline, banner
2. **High (this week):** About section, Featured section
3. **Medium (this month):** Experience rewrite, Recommendations requests
4. **Ongoing:** Post frequency, comment frequency, content quality
