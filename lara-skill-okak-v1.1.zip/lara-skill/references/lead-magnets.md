# Lead Magnets That Actually Convert

## When to use
- User asks: "How do I build an email list from LinkedIn?"
- User asks: "What's a good lead magnet for [topic]?"
- User says: "My content gets views but no emails"
- When building any giveaway post or DM follow-up sequence

## The core principle: the rented-land problem

LinkedIn owns your audience, not you. When you post, only 2-3% of your followers see it. That's the algorithm tax.

The smartest creators solve this by moving people from LinkedIn (rented land) to email (owned land). Lead magnets are the bridge.

Lara's number: **70% of her revenue comes from email**, but the email list is fed by LinkedIn. You need both legs.

## Three lead magnet types that work in 2026

### 1. Value-Overload Lead Magnet
Show exactly what they'll get. Concrete, immediate, no fluff.

**Examples:**
- "10 LinkedIn hook templates that drove 3M+ impressions"
- "The complete cold email script library (47 templates)"
- "All my Notion dashboards for tracking content performance"

**When to use:** The resource genuinely has high standalone value. The reader thinks "I could spend $200 on a course for this."

### 2. Secret-Formula Lead Magnet
Lead with the outcome, then say the answer is one email away.

**Examples:**
- "This 4-step DM script booked me 60 calls in 6 months. Get the exact template in your inbox."
- "I went from 0 to 320K LinkedIn followers in 4 years using ONE framework. Here's what it is."
- "The 3-word subject line that gets 60%+ cold email open rates."

**When to use:** You have a specific, proven outcome to point to. The "formula" framing creates urgency.

### 3. Free AI Agent / Custom GPT
Pre-loaded with your proprietary framework. Today's highest-converting format because it taps the AI trend and feels like a $1,000 product for free.

**Examples:**
- "A custom GPT trained on my entire LinkedIn content strategy. Ask it anything."
- "A Claude project that writes your lead magnet emails in your voice. Free for the next 48 hours."
- "An AI agent that scores your hooks against the top 1% of LinkedIn posts. Free with your email."

**When to use:** You have proprietary knowledge to encode. The "AI tool" framing is novel, shareable, and creates an immediate "I need this" reaction.

## The giveaway post structure

```
[Specific outcome or contrarian hook in line 1]

[Why this matters — 1-2 lines]

Comment [WORD] and I'll DM you the [resource name].

Bonus: [Second piece of value, optional]
```

**Critical rules:**
- The word they comment must be short and easy to type (1 word, lowercase).
- The promise must be deliverable. If you say "AI tool," you must actually send a working tool, not a Notion page.
- Add a deadline only if it's real. Fake urgency kills trust.

## Posting frequency

Lara's team runs **2 lead magnet posts per week per client**. Some niches can run 1-2 per month. Don't run more than 4/week total across all post types.

**Why frequency matters:** Each lead magnet post is a separate comment-collection event. Running them less than weekly means your audience forgets the pattern. Running them too often trains your audience to expect free stuff instead of buying.

## What to do with the comments

Once someone comments the trigger word:

1. **Send the resource** (DM 1 — no pitch)
2. **Add a credibility line** (DM 2)
3. **Add tactical value** (DM 3)
4. **Soft proof** (DM 4)
5. **Soft CTA** (DM 5 — only after they reply)

For the full 5-message flow, see `dm-playbook.md`.

## Lead magnet mistakes

### Mistake 1: 50-page PDF
Lara: "Nobody is going to go through 50 pages of plain text."

The 20/80 rule: find the 20% of information that gets 80% of the result. That's your lead magnet. Be concise.

### Mistake 2: Generic / AI-generated slop
The complaint that "lead magnets feel spammy" is almost always because the lead magnet itself is low quality. ChatGPT-spun content with no real insight = spam.

### Mistake 3: Asking for too much
Don't ask for name + email + phone + company + revenue + team size for a free PDF. The ask is just an email. Make it easy.

### Mistake 4: No follow-up
A lead magnet that just delivers a PDF and goes silent is wasted. The 5-message flow exists to convert the comment into a call. If you're not running the flow, don't bother with the lead magnet.

### Mistake 5: No measurement
Track: comments per post, emails captured, replies in DM, calls booked. If a lead magnet isn't producing calls, kill it.

## Lead magnet + email funnel

The full pipeline:

```
LinkedIn post (giveaway)
  ↓ comment
DM 1: deliver resource
  ↓ reply
DM 2: credibility
  ↓ reply
DM 3: tactical value
  ↓ reply
DM 4: proof
  ↓ reply
DM 5: CTA → call
  ↓ booked call
Email nurture (5-7 emails over 2 weeks)
  ↓ engaged subscriber
Pitch offer
```

If you skip the email nurture step, you're leaving 50%+ of revenue on the table. The DM gets them on a call today. The email list gets them on a call next month, or next quarter, or next year.

## Quick-win lead magnet ideas

If the user is stuck on what to make:

1. **Audit their last 10 posts.** What's the most-saved or most-shared? Turn that into a lead magnet.
2. **Audit their DMs.** What do prospects ask over and over? Make a resource that answers it.
3. **Steal from their inbox.** What questions do clients ask in the first call? Make the answer a lead magnet.
4. **Pull from their SOPs.** Internal docs often have the best frameworks. Refactor one into a public resource.
5. **Use the AI agent format.** Take any framework, encode it in a Custom GPT, give it away. Instant lead magnet.

## When NOT to use a lead magnet

- You're not ready to monetize. Don't collect emails you won't email.
- Your ICP doesn't use email. (Rare on LinkedIn, but possible.)
- You have nothing of value to teach. Lead magnets require real insight. No insight = no lead magnet.
- You don't have a follow-up system. Without the 5-message flow + email nurture, the lead magnet leaks.
