# Post Templates — Ready to Adapt

Each template comes from Lara's actual playbooks. Adapt them to your SMPV. Don't ship them as-is — your voice is the moat.

## 1. The Storytelling Post (SLAY framework, Thursday)

**Use when:** You have a personal moment that reveals something universal.

```
[Specific moment — in the scene]

[What you felt or thought at the time]

[What changed — the shift]

[Lesson framed as takeaway for the reader]

[Optional: 1-line reflection or question]
```

**Example (Lara's "first millionaire" post):**
```
POV: I became the first millionaire in my family.

[Photo of Lara and her dad]

Here's the thing nobody tells you about that moment.

[Specific detail only you would know]

The lesson isn't about money. It's about [universal takeaway the reader can apply].

If you're [the ICP's situation], this might be the permission slip you need.
```

**The "in the middle of things" rule:** Don't say "I once gave a talk." Say "I just walked offstage and my hands were shaking." Drop them into the moment.

**The reframing rule:** Line 2 must invite projection. "I never thought I'd be the kind of person who…" works because the reader fills in their own blank.

---

## 2. The Document Post (Adam Robinson pattern, Wednesday)

**Use when:** You have a specific number to share.

```
[Specific dollar figure or metric — the bigger the better]

[Screenshot of the proof — Stripe, dashboard, LinkedIn analytics]

[One specific detail nobody else can copy]

[One thing that almost went wrong]

[What this means for the next 30 days]
```

**Example:**
```
We made $87,432 last month.

[Stripe screenshot]

Here's what nobody sees: [specific internal detail — a customer service email, a team call, a system that broke].

The number that's not in the screenshot: [the hidden metric that mattered more].

Next 30 days: [what you're doing differently]. Follow if you want the breakdown.
```

**The screenshot rule:** Without it, the number is a claim. With it, it's proof. Lara's view: "You can't argue with proof."

---

## 3. The Educate Post (PAS framework, Tuesday)

**Use when:** You're teaching something tactical that solves a specific problem.

```
[Problem — in the ICP's language, not yours]

[Agitate — why this matters now, what happens if they don't fix it]

[Solution — broken into 3-5 specific steps, lived-experience detail]

[Result — what they'll get if they implement this]
```

**Example (Daniel Bustamante's phone-addiction post):**
```
My phone addiction has been out of control lately.

Over the past two weeks I've been impulsively checking LinkedIn, Substack, Gmail way more than I'd like to admit.

So I'm doing something about it.

[Step 1: specific action]
[Step 2: specific action]
[Step 3: specific action]

The first 48 hours were brutal. [Specific result after 1 week].
```

**The lived-experience rule:** Use specific language only someone who actually did it would know. "I noticed I check my phone 47 times a day" beats "I check my phone a lot."

---

## 4. The Lead Magnet Giveaway Post

**Use when:** You want to capture emails from a high-engagement post.

```
[Specific outcome the reader wants — the bigger the better]

[Why this is hard to find or do alone]

[What the lead magnet contains — concrete, not vague]

Comment [WORD] and I'll DM you the [resource name].

[Optional bonus or deadline]
```

**Example:**
```
98.2% of LinkedIn users will never post a single word.

The 1.8% who do get 10x the inbound.

I just packaged the exact framework the 1.8% use to write posts that drive 500+ sign-ups per month.

It's called The Hook Library — 47 templates pulled from posts that hit 1M+ impressions.

Comment "HOOKS" and I'll DM you the link.

(Yes, it's free. Yes, I'll actually send it.)
```

**The trigger word rule:** Short, lowercase, easy to type. "HOOKS," "READY," "POST," "GUIDE" all work. "TRANSFORMATIONAL_LEADERSHIP_FRAMEWORK" doesn't.

**The deliverability rule:** If you promise an AI tool, send a working tool. If you promise a Notion dashboard, send a working dashboard. Broken promises kill trust faster than anything else on LinkedIn.

---

## 5. The Sell Post (Sunday)

**Use when:** You have an offer open and want to drive inbound.

```
[Customer-style opening — "Most [ICP] think X. I did Y instead."]

[Their specific outcome — number, timeframe]

[How you helped them get there — 2-3 sentences]

[What you're offering now — specific, time-bound]

[Single clear CTA]
```

**Example:**
```
Most [B2B SaaS founders] think they need more content to get more leads.

We did the opposite.

We cut our posting from daily to 4x/week. Removed all the "thought leadership fluff."

Booked calls went from 3/week to 14/week in 90 days.

I have 3 spots open this month for [specific offer].

DM me "GROWTH" if you want to talk.
```

**The specificity rule:** "3 spots," not "limited spots." "This month," not "soon." "14 calls in 90 days," not "massive growth." Specificity = credibility.

**The single-CTA rule:** One offer, one ask, one CTA per sell post. Don't list 5 services. Don't add 3 different links. One thing.

---

## 6. The Contrarian Post (sparingly)

**Use when:** You have a genuine, defensible opinion that runs against the consensus.

```
[Common belief in your industry]

[Why most people believe it]

[Why it's wrong — your lived-experience counter-example]

[What this means for the reader]
```

**Example (Lara's "people hate LinkedIn" post):**
```
I see a lot of founders posting "I hate LinkedIn, everyone uses AI now."

LinkedIn is just other people.

The people making those AI posts are first-timers trying their best.

If you got better feedback than "this sucks" when you started, you're lying.

Be the person who helps instead of hates.
```

**The "true to you" rule:** Lara's test: "If I actually believe this, I'll post it once a month. If I just want engagement, I'll be known as the hater." Genuine contrarianism builds brand equity. Manufactured contrarianism kills it.

---

## 7. The Engagement-Bait Post (use carefully)

**Use when:** You want to seed comments that get the algorithm moving.

```
[Hot take or specific question that splits the room]

[Context — why this matters]

[Ask the question explicitly]
```

**Example:**
```
Hot take: Cold DMs are a waste of time in 2026.

If your profile doesn't make the ICP's problem obvious in 5 seconds, no DM is going to save you.

I've sent 50,000 DMs over 4 years. The ones that worked had one thing in common: my profile had already done the work.

Disagree? Tell me why.
```

**The no-likes-asked rule:** Never end with "Like if you agree" or "Follow for more." The bait is the question. The engagement is the reply.

**The "split the room" rule:** If everyone agrees, rewrite. The best engagement posts create two camps.

---

## 8. The Personal-But-Tactical Post

**Use when:** You have a personal moment that maps to a business lesson.

```
[Personal moment — specific, vulnerable]

[The feeling or lesson it surfaced]

[How this applies to [business / ICP situation]]

[Takeaway the reader can use today]
```

**Example:**
```
I just got engaged.

[I never thought I'd be the kind of person who would marry the girl of my dreams.]

[Tactical lesson — e.g., "The same thing happens in business: you over-pitch the thing that hasn't worked, and ignore the obvious match in front of you."]

If you're [ICP situation], [takeaway they can apply today].
```

**The reframe rule:** The engagement came from the personal news. The takeaway came from the business lesson. If you skip line 2, this is a wedding announcement. If you skip line 4, it's just journaling. Both are required.

---

## Formatting rules (apply to every post)

1. **First line = the hook.** Bold it visually with a line break before it. Use a short sentence.
2. **One- and two-sentence paragraphs.** Almost no headers in the body.
3. **No emoji spam.** One or two per post max, if any.
4. **No "I" walls of text.** Break every 1-2 sentences with a line break.
5. **Single CTA at the end.** Or none at all if it's a storytelling post.
6. **Read aloud test.** If you stumble, rewrite.
7. **Word count sweet spot:** 150-300 words for storytelling/document posts. Up to 500 for educational. Under 100 for quick tactical posts.

## The post-creation workflow

1. **Pick the pillar** (Tue educate, Wed document, Thu story, Sun sell).
2. **Pick the angle** (broad → narrow → niche).
3. **Draft the hook** (first 3 lines, broad → narrow → niche).
4. **Draft the body** using the matching template above.
5. **Strip filler.** Cut every sentence that doesn't add information or emotion.
6. **Add the CTA.** One only. Specific.
7. **Read aloud.** If you stumble, rewrite.
8. **Post Tue/Wed/Thu/Sun.** Same time every week if possible.
