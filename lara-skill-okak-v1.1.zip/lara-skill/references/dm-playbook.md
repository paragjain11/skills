# LinkedIn DM Playbook

Two distinct DM use cases. Use the right script for the right situation.

## Use case A: Lead magnet follow-up (someone commented on your post)

The 5-message flow. Source: Paolo Trivellato interview with Lara, chapter "The 5-Message DM Flow That Books Calls Without Pitch Slapping."

### DM 1 — Deliver the resource
No pitch. Just send what they asked for. One sentence max.

> "Hey [name] — here's the [resource]: [link]. Hope it helps."

### DM 2 — Quick credibility line
One sentence on why you're qualified. Don't oversell.

> "Built this after working with 50+ [ICP] who all had the same problem."

### DM 3 — Tactical value
A specific tip they can implement immediately. Show, don't tell.

> "Quick tip if you implement this: skip step 2 entirely. It's the part everyone over-engineers."

### DM 4 — Soft proof
A short case study or result.

> "Last month someone used this exact framework and booked 3 calls in their first week. The trick was skipping step 2."

### DM 5 — Soft CTA
Only after they've engaged (replied, thanked, asked a question).

> "If you want help implementing this for your business, I have a few spots open this month. Worth a 15-min chat?"

**Hard rule:** Never pitch in DM 1. The resource IS the pitch. Trust compounds.

**Cadence:** Wait 24h between DMs 1-2. Wait 48h before DMs 3-4. CTA only after they reply. If they don't reply to DM 4, drop it for 2 weeks, then send value-only (a new resource, a relevant post), no CTA.

---

## Use case B: Cold outreach DM (no prior touch)

The 3 must-haves of a winning cold DM. Source: Lara via Woodpecker interview.

### 1. Length — industry-dependent
- **Creative industry:** Short. 1-2 sentences. Get to the point.
- **Professional services:** Longer paragraphs okay. They expect context.
- **Read-aloud test:** Read it out loud. If you lose interest after the first sentence AND don't know what to do by the end, the length is wrong.

### 2. First sentence — their problem, not your name
**Banned opener:** "Hi, my name is [X], I work at [Y], we help [Z]."

Lara's reaction: "Why are you telling me about you? I don't have time. Maybe I'm on the go. That's not how you start."

**Good opener:** "Saw you're scaling to [X] — most [ICP] hit a wall at [Y] when [Z]. I help them solve [W]."

### 3. Clear CTA
**Weak:** "Thoughts?" "Let me know if interested." "Open to chatting?"
**Strong:** "Worth a 15-min call Wednesday at 2pm? Here's my calendar: [link]."

Make it easy to say yes. Specific time, specific duration, low commitment.

---

## Templates

### Cold DM — Agency-to-founder
```
Hey [name] — saw your post about [specific thing they posted].

Most [their ICP] hit a wall at [specific pain point] when they try to [specific outcome without your help]. I help them fix this in [timeframe] without [common objection].

Worth a 15-min call Thursday? [calendar link]
```

### Cold DM — B2B SaaS to enterprise
```
[Name] — noticed you're hiring [X role]. That usually means [specific signal of growth].

The bottleneck I see at this stage is [specific problem]. We helped [named company or "a Y-Combinator B2B SaaS"] cut [metric] by [number] in [timeframe].

Open to a 20-min look at how it'd apply to [their company]?
```

### Follow-up after no reply
```
[Name] — totally fine if the timing's off. Just wanted to flag [one specific piece of value, not a re-pitch].

Worst case it's free insight. Best case we chat in Q[X].
```

---

## Anti-patterns (will get you blocked)

- "Just checking in" — never.
- "Bumping this up" — never.
- Long-form pitch in DM 1 — never.
- "Are you the decision-maker?" — patronizing. They know if they are.
- "I'd love to pick your brain" — give value, don't extract it.
- Sending the same template to 200 people with only the name swapped — they'll know.

---

## What to do when they reply

If they say yes:
- Send a calendar link with a specific proposed time.
- Show up on time.
- Don't pitch in the first 5 minutes. Ask about their situation first.

If they say no:
- Thank them for their time.
- Don't argue. Don't "but wait." Leave the door open: "If anything changes, you know where to find me."

If they ghost:
- 2 follow-ups max, spaced 4-7 days apart, each one adding new value (a relevant article, a tip, an introduction).
- After 2 follow-ups with no reply, drop it.
