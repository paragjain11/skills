# Lara — Quick Reference

A one-page cheatsheet. Use this when you need the framework fast.

## The 5-frameworks-at-a-glance

| Framework | One-liner | When to use |
|-----------|-----------|-------------|
| **SMPV** | Skill + Market + Problem + Value = what you should be known for | "I don't know what to post about" |
| **4-3-2-1** | 4 posts/week, 3 pillars, 2 audiences, 1 sales topic | Building any content calendar |
| **SLAY** | Story → Lesson → Action → You | Writing a storytelling post |
| **PAS** | Problem → Agitate → Solution | Writing an educational post |
| **ICP + IFP** | Write for the buyer AND the audience-finder | Balancing reach vs conversion |

## The 7 content rules

1. **Hook = broad → narrow → niche** (first 3 lines)
2. **Post 4x/week max** (Tue, Wed, Thu, Sun)
3. **Rotate pillars:** Educate, Document, Storytell, Sell
4. **Lead with numbers, not adjectives**
5. **Read aloud before posting** (if you stumble, rewrite)
6. **Single CTA per post** (or none)
7. **One voice, one skill, one market**

## The 5 cold-DM rules

1. **Length = read aloud test** (don't lose interest)
2. **First sentence = their problem** (never your name)
3. **CTA = specific time + duration** ("Worth 15min Wednesday 2pm?")
4. **No pitch in DM 1** (the resource is the pitch)
5. **2 follow-ups max** (each adding value, never "just bumping")

## The 3 lead magnet types

1. **Value Overload** — "10 LinkedIn hooks that drove 3M+ impressions"
2. **Secret Formula** — "This DM script booked me 60 calls. Get the template."
3. **Free AI Agent** — "A Custom GPT trained on my entire strategy. Free."

## The 5-message DM flow (lead magnet → call)

1. DM 1: deliver the resource (no pitch)
2. DM 2: one-line credibility
3. DM 3: tactical value they can use today
4. DM 4: short case study / proof
5. DM 5: soft CTA → "Worth a 15-min chat?"

## The 4 sell post methods (Sunday)

1. **Halo effect** — talk about an authority in your space
2. **In-depth breakdown** — show your exact process end-to-end
3. **Customer-eye storytelling** — narrate their outcome
4. **LinkedIn Live** — compress attention → trust → conversion

## The "be useful not interesting" checklist

Before posting anything, ask:

- [ ] Does the hook name a specific problem my ICP has?
- [ ] Does the body deliver value (story, framework, proof) the reader can use?
- [ ] Does the CTA make it easy to take the next step?
- [ ] Would I be okay with my ICP's competitor reading this?
- [ ] Did I read it aloud and it actually sounded like me?

If any answer is no, rewrite.

## The SMPV one-liner test

In one sentence, complete this: "I help [specific market] get [specific outcome] through [specific method]."

If you can't, you don't have an SMPV yet. Get one before posting anything else.

Examples:
- ✅ "I help B2B SaaS founders book 10+ qualified sales calls per month from LinkedIn content."
- ❌ "I help businesses grow through digital marketing."
- ✅ "I help financial advisors get 2-3 ideal clients per month through relationship-first LinkedIn outreach."
- ❌ "I'm a financial advisor who loves LinkedIn."

## The ICP vs IFP split

When you write a post, ask: "Who is this for?"

- **ICP posts** = educational, niche-specific, problem-solving. Speaks to the buyer.
- **IFP posts** = storytelling, broad, personal. Speaks to the audience-finder.

Aim for 50/50. If you're under 10K followers, lean IFP (storytelling) for reach. If you're over 10K, lean ICP for conversion.

## The 4 stages of LinkedIn networking

1. **Absent** — no profile or no activity
2. **Lurker** — profile exists, no posts/comments
3. **Networker** — comments regularly, posts occasionally
4. **Influencer** — posts consistently, recognized voice

**Most people are stuck at Stage 2.** Commenting moves you to Stage 3. Posting moves you to Stage 4.

## The "rented land" principle

LinkedIn owns your audience, not you. When you post, 2-3% of followers see it. The algorithm tax.

Move people from LinkedIn (rented land) → email (owned land). Lead magnets are the bridge.

Lara: **70% of her revenue comes from email**, but the email list is fed by LinkedIn.

## The 3 hard rules (never break)

1. **Don't pitch in DM 1.** The resource is the pitch.
2. **Don't post more than 4x/week.** Quality collapses.
3. **Don't ask for likes or follows.** Write something worth engaging with.

## The 3 anti-patterns (always push back on)

1. **Generic headlines** — "Founder | Speaker | Investor" tells the reader nothing.
2. **Lifestyle-only content** — kills category recognition if it doesn't ladder to SMPV.
3. **AI slop posts** — one-prompt wonders without the user's voice. Always rewrite.

## The Lara voice

Direct, never corporate. Contractions. One- and two-line paragraphs. Numbers over adjectives. No "hope this helps" closers.

When in doubt: be the strategist in the room, not the assistant.
