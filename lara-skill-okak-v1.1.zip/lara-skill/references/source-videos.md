# Source Material — 7 Videos Behind the Lara Skill

This skill is built directly from Lara Acosta's actual frameworks as taught across 7 videos. Use this index when you need to cite a specific source or dig deeper into a specific play.

## The videos

### 1. "I asked Lara Acosta How to Get Rich with LinkedIn" — Harry Phokou
- **Length:** 1h28m
- **URL:** https://www.youtube.com/watch?v=D82Lj653BHI
- **What it gives you:** The deepest source on Lara's full system — SMPV, 4-3-2-1 in practice, ICP/IFP distinction, the "influence not influencer" thesis, the AI-writing-partner workflow, the team-posting Miro board system, the "in the middle of things" storytelling rule, and the lead magnet → DM → email → call funnel in action.
- **Key chapters:**
  - "Lara Acosta, Kleo V3 & the organic launch" — real example of content → product launch
  - "How to build a personal brand that makes money" — ICP/IFP distinction
  - "Why Lara turns down paid brand deals" — money-making vs brand-building deals
  - "Storytelling vs expertise" — content archetypes
  - "How to get your entire team posting on LinkedIn" — the Miro board system
  - "Breaking down a viral post that drove 500+ sign-ups" — hook anatomy
  - "Building a repeatable LinkedIn content system" — Kleo
  - "Harry's 'revenue power hour' for outbound" — the 100-connection system

### 2. "Showing Lara Acosta How I Book 100+ Calls/Mo From LinkedIn (Without a Big Following)" — Paolo Trivellato
- **Length:** 32m
- **URL:** https://www.youtube.com/watch?v=GMQe-h5aInk
- **What it gives you:** The 5-message DM flow that converts lead magnet comments into booked calls without pitch-slapping. The three awareness stages (Problem Unaware → Problem Aware → Solution Aware). Lead magnet frequency (2/week/client). Namejacking. Trend-spotting.
- **Key chapters:**
  - "The Lead Magnet System Explained"
  - "What Makes a Lead Magnet Actually Work (The 20/80 Rule)"
  - "The 5-Message DM Flow That Books Calls Without Pitch Slapping"
  - "The 3 Awareness Stages (Problem Unaware → Solution Aware)"
  - "How to Generate Viral Post Ideas Using Competitor Research"
  - "The LinkedIn Algorithm in 2026: What Actually Matters"
  - "$100K/Month at 18: How Many Clients, What I Charge, How I Get Them"
  - "Namejacking: The Fastest Way to Reach New Audiences on LinkedIn"

### 3. "The NEW LinkedIn Strategy you need to Blow Up in 2026" — Lara's own channel
- **Length:** 21m
- **URL:** https://www.youtube.com/watch?v=JDZYNJQOee0
- **What it gives you:** The 4-3-2-1 framework in its most formal articulation. The Tue/Wed/Thu/Sun calendar. The document-with-numbers playbook (Adam Robinson pattern). The "rented land problem" and the case for email. The three lead magnet types (value overload, secret formula, free AI agent).
- **Key chapters:**
  - "Why LinkedIn is the best platform right now"
  - "The 4-3-2-1 content framework explained"
  - "Educate / Document / Storytell / Sell — the day-of-week split"
  - "ICP vs IFP and how to balance both"
  - "The value bridge: 3 types of lead magnets"
  - "Going viral vs growing in your niche"

### 4. "Lara Acosta's best LinkedIn cold outreach tips" — Woodpecker.co
- **Length:** 5m
- **URL:** https://www.youtube.com/watch?v=sXcw6-wdrzA
- **What it gives you:** The shortest, sharpest distillation of Lara's cold DM rules. The 3 must-haves (length, first sentence, CTA). The "why are you telling me about you?" opener rule. Real DM examples with Lara's annotations.
- **Use this when:** The user wants a quick DM refresher and doesn't need the full 5-message flow.

### 5. "World's No 1 LinkedIn Creator: I'll 10x Your Reach in 92 Minutes" — Callum McDonnell
- **Length:** 1h32m
- **URL:** https://www.youtube.com/watch?v=WLxbYHYKasI
- **What it gives you:** The SMPV framework walked through in detail. The broad/narrow/niche hook architecture. The ideal follower persona (the audience-finder for your audience). Storytelling as the highest-reach format. Email as the real monetization engine.
- **Key chapters:**
  - "The SMPV framework (skill, market, problem, value)"
  - "Selling to the right audience (and why most creators are broke)"
  - "Content that drives leads vs content that gets likes"
  - "The 4-3-2-1 content framework explained"
  - "Why email is the real monetisation engine"
  - "Building brand equity vs constantly selling"
  - "Building community through comments"
  - "Why you shouldn't outsource your personal brand too early"

### 6. "If I lost it all today, here's how I'd make $2.1M ASAP in 2026 (using LinkedIn)" — Lara's own channel
- **Length:** 38m
- **URL:** https://www.youtube.com/watch?v=Qz003lp_5vA
- **What it gives you:** The step-by-step SMPV walkthrough with three worked examples (creator-to-entrepreneur, Lara's own story, AI-curious beginner). The exact ChatGPT market-research prompt Lara uses with her audience.
- **Use this when:** The user is stuck at "I don't know what to sell or who to sell to."

### 7. "The Problem With Personal Branding: Lara Acosta" — James Smith Show
- **Length:** 1h22m
- **URL:** https://www.youtube.com/watch?v=2cNB5_v4EAw
- **What it gives you:** The philosophical foundation. "Be useful, not interesting." The WIIFM principle. Ego vs growth. "Everyone wants a personal brand but no one knows what it means." Why introverts win personal branding in 2026. The writing/communication/manipulation thesis.
- **Key chapters:**
  - "The Problem With Personal Branding"
  - "Be Useful, Not Interesting"
  - "Ego Is Slowing Growth"
  - "Retrospective Storytelling Wins"
  - "Hooks Plus Visual Hooks"
  - "Why 2026 Belongs To Writers"
  - "Email Lists Beat Platforms"

---

## How to use this index

When the user asks a question, identify which framework applies, then check this index for the deepest source on that framework.

| User question | Best source video |
|--------------|-------------------|
| "I don't know what to post about" | #6 (SMPV walkthrough) or #5 (SMPV detail) |
| "Build me a content calendar" | #3 (4-3-2-1 formal) or #5 (with examples) |
| "Write me a LinkedIn post" | #1 (variety) + #2 (Paolo conversation) |
| "How do I get leads from LinkedIn?" | #2 (5-message DM flow) + #3 (lead magnets) |
| "How do I do cold outreach?" | #4 (3 must-haves) + #1 (Harry's revenue power hour) |
| "My content isn't converting" | #7 (philosophy) + #1 (the compounding argument) |
| "What's the algorithm doing?" | #2 (algorithm chapter) + #3 (rented land argument) |
| "Should I be on LinkedIn?" | #3 (why LinkedIn) + #7 (writing thesis) |
| "How do I monetize my audience?" | #5 (email engine) + #6 ($2.1M framework) |
| "Help me write a cold DM" | #4 + #2 (DM flow) |
| "Should I hire someone to write for me?" | #5 (don't outsource too early) + #1 (AI writing partner) |
| "How do I write better hooks?" | #1 (viral post breakdown) + #5 (broad/narrow/niche) |
| "Build me a lead magnet" | #3 (3 lead magnet types) + #2 (20/80 rule) |

---

## The cross-video themes

When you're coaching the user, the same handful of principles keep showing up across all 7 videos. These are the load-bearing ideas. Use them everywhere.

1. **Be useful, not interesting.** (#7)
2. **Influence, not influencer.** (#1)
3. **Consistency doesn't negate quality.** (#1, #3, #5)
4. **Storytelling beats educational content for reach.** (#3, #5)
5. **Engineer the post to succeed, then make it yours.** (#1, #5)
6. **ICP + IFP, not just ICP.** (#3, #5)
7. **Email is the real business asset.** (#3, #5)
8. **Specific numbers + screenshot = trust.** (#3)
9. **What's in it for me principle.** (#1, #7)
10. **Compound content + DMs + commenting.** (#1, #2)
