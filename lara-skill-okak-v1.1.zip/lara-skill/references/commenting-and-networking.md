# Commenting & Networking Playbook

## Why this matters

Lara's rule: "You can definitely do one [content or DMs] but if you have at least some posts out there that show you know what you're doing, yeah I think you'd murder it."

Content and DMs compound. So does commenting. The people whose posts you comment on notice you. They check your profile. They follow. They remember. They hire you or refer you.

## The daily commenting habit

**Target:** 5-10 comments per day on posts in your niche.

**Where to comment:**
- People in your ICP (potential clients)
- People at your level (peers who could become referral partners)
- People 1-2 steps ahead of you (potential mentors or collaborators)
- Your own past commenters (reciprocity)

**What NOT to do:**
- "Great post! 🙌" — wastes your time and theirs
- "Agreed! 🔥" — adds nothing
- Long-form counter-arguments on unrelated tangents — makes you look combative

**What TO do:**
- Add a specific insight, counter-point, or personal story
- 2-4 sentences. Not a paragraph. Not a one-liner.
- Reference something specific from their post
- End with a question or a thought that adds to the conversation

**Example of a good comment:**
Original post: "I made $50K last month from LinkedIn."

Weak comment: "Congrats! 🔥"

Strong comment: "Curious — was this from inbound DMs or from your email list? I find that the people who closed fastest came from email, not LinkedIn DMs."

The strong comment shows you're paying attention, adds a specific observation, and invites a reply.

## The 4 stages of LinkedIn networking

From Lara and from Joe Apfelbaum's networking framework:

1. **Absent.** You're not on LinkedIn at all, or you have a profile with no activity. Invisible.
2. **Lurker.** You're on LinkedIn but you don't post or comment. People can find you but they don't know you exist.
3. **Networker.** You comment regularly. You post occasionally. You're building relationships. People recognize your name.
4. **Influencer.** You post consistently. You have a recognizable voice. People refer to you. People tag you. People quote you.

**Most people get stuck at Stage 2.** They think lurking is enough. It isn't. Commenting moves you to Stage 3. Posting moves you to Stage 4.

## The 1-1-1 weekly habit

Pick 1 person per week to do all three of:
1. Comment thoughtfully on one of their posts
2. Send them a DM with something valuable (a resource, an introduction, a relevant article)
3. Mention them in one of your posts (with credit, not in a weird "tag-for-engagement" way)

This compounds over 6-12 months. A year of 1-1-1 means you've built real relationships with 50+ people in your niche.

## Coffee chats & DM relationship-building

Lara: "How did you get this network? I started doing coffee chats. Next day I see Harry on a 30-day challenge to do coffee chats with whoever said yes."

The cold-DM-to-coffee-chat script:

```
Hey [name] — saw your post about [specific thing]. [One specific thing you liked or disagreed with.]

I help [ICP] with [outcome]. Not pitching anything.

Worth a 20-min video coffee next week? No agenda, just curious about your work.
```

The "no agenda" framing removes the pressure. Many coffee chats turn into referrals, intros, or future clients even without a "pitch."

## When someone comments on YOUR post

This is the highest-intent moment. Don't waste it.

**Within 24 hours:**
- Like their comment
- Reply to it (with substance, not just "thanks!")
- If their comment is substantive, send a DM (NOT a pitch — value first)

**The follow-up DM after a comment:**
```
Hey [name] — saw your comment on my post about [topic]. [One specific thing they said.]

[Add value — a resource, a thought, an intro]

No pitch. Just thought it might be useful.
```

## Engagement pods: why they don't work

Lara's implicit view (and the data backs it up): engagement pods — where you and 10 friends all like/comment on each other's posts — train the algorithm to think your content is interesting to a small group of strangers, then it stops showing your content to anyone else.

The compounding effect of real commenting beats any pod. Real comments from real people in your niche > 50 fake engagements from a pod.

## The "DM 100 connections/week" system

Harry Phokou's system (from the Lara interview):

1. **Identify 100 people per week** who are qualified for your offer. Build a list (Sales Navigator, manual search, scrapers).
2. **Send 20 connection requests per day.** ~30% accept = 6 new connections per day = 30 per week.
3. **Send a personalized DM after each acceptance.** "Thanks for connecting. Saw [specific thing about them]. I help [ICP] with [outcome]. Open to a 20-min chat?"
4. **Follow up every 3-5 days** until they say yes or no. "Just bumping this. Still relevant?"
5. **Use a CRM** (even a spreadsheet) to track who you've messaged, who replied, who said no.
6. **Time commitment:** ~20 min/day. Harry calls it his "revenue power hour."

**Expected conversion:** 10% of DMs book a call. 100 DMs/month = 10 calls/month. Some of those close.

## Networking events & LinkedIn Lives

Lara's view on LinkedIn Lives: "If you can't go to a conference or create one, LinkedIn Lives are usually the safest bet because you can just do it at home while meeting people that follow you."

LinkedIn Live playbook:
- Announce the live 3-5 days in advance across multiple posts
- Have a clear topic and 3-5 talking points
- Invite a guest if possible (their audience + your audience = compound reach)
- Go live for 30-45 minutes
- Post the replay as native video within 24 hours
- DM everyone who attended or commented

The live compresses time between attention → trust → conversion because you're talking to people directly.

## The networking mindset

Lara: "Because you got pitched badly, you've experienced door-knocking sales, you've experienced pitch-slapping. That doesn't mean you have to do that."

**The two mindsets that work:**
1. **Help first, sell later.** Most of your outreach should be value-first. The sale comes later (sometimes much later).
2. **Persistence ≠ pushy.** Following up 3-5 times without pressuring is persistence. Following up 10 times in a week is pushy.

**The mindset that doesn't work:**
- "Everyone who connects is a potential sale." No. Most people aren't ready to buy. Be patient. Stay visible. Sell when they're ready.

## How to apply

When the user asks about networking, growth, or engagement:

1. Diagnose what stage they're at (Absent / Lurker / Networker / Influencer).
2. Recommend the smallest next step to move them up one stage.
3. Build the daily commenting habit before pushing them to post more.
4. Remind them: commenting + DMs + content together is what compounds. Any one alone is slower.
