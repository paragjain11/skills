# The 4-3-2-1 Content System

## When to use
- User asks for a content calendar / 30-day plan / weekly schedule
- User asks "what should I post about"
- User wants to operationalize posting without burning out

## The framework

**4 posts per week.** Four is the cap for written content. More than that and quality collapses. Best days: Tuesday, Wednesday, Thursday, Sunday.

**3 content pillars** rotating across the week:

| Day | Pillar | Format | Job to be done |
|-----|--------|--------|----------------|
| Tuesday | **Educate** | PAS structure (Problem → Agitate → Solution) | Position as the niche authority. Speak to the warm audience that knows they have the problem. |
| Wednesday | **Document** | Numbers + screenshot + imperfect writing | Build-in-public. Lead with a specific dollar figure or metric. Attach proof. Show don't tell. |
| Thursday | **Storytell** | SLAY framework (Story → Lesson → Action → You) | Reach the cold audience. Vulnerability > polish. The highest-reach format on LinkedIn. |
| Sunday | **Sell** | One of four methods | Capture attention, retain viewer, leave them wanting more. Convert. |

**2 audiences to write for:**
- **ICP (Ideal Client Persona):** Buyer. Decision-maker. Has the problem + budget. Educational content speaks to them.
- **IFP (Ideal Follower Persona):** Not buying today but will in 1–5 years. They're the audience-finder for your ICP. Storytelling content speaks to them.

Most creators over-optimize for ICP. That's why their hooks all sound the same. The IFP is what gives you reach.

**1 single sales topic per week.** Every post ladders up to one offer, one CTA, one thing you want the reader to do.

## The 4 Sell methods (Sunday)

1. **Halo effect.** Talk about someone who is an authority in your industry. Borrow their credibility to surface your own.
2. **In-depth breakdown.** Spend the time to show your exact process end-to-end. Asset-style post.
3. **Storytelling from your customers' eyes.** Narrate how they felt, what they achieved, the financial/emotional/personal gain.
4. **LinkedIn Live.** The fastest way to compress time between attention → trust → conversion.

## Worked example: 1 week

| Day | Pillar | Hook angle | CTA |
|-----|--------|-----------|-----|
| Tue | Educate | "98.2% of LinkedIn users never post. Here's what the 1.8% do differently." | "Comment 'POST' and I'll send the framework." |
| Wed | Document | "We made $87K last month. Here's the exact breakdown." + screenshot of Stripe | "Follow for the full breakdown every Wednesday." |
| Thu | Storytell | "In 2021 I was broke. By 2026, I'm [specific outcome]. Here's what changed." | None, or one soft question. |
| Sun | Sell | "5 spots open this month for [service]. Here's what one client achieved in 30 days." | "DM me if you want to talk." |

## Worked example: 1 month (4 weeks)

For each week, pick:
- 1 lead magnet post (usually Wed or Thu)
- 1 storytelling post (Thu)
- 1 educational post (Tue)
- 1 sell post (Sun)

Rule: minimum 1 lead magnet post/week. Some niches can run 2/week. Don't go above 4/week total.

## Document post playbook (Wednesday)

The Adam Robinson pattern:

1. **Hook = specific number.** "We made $600,000 last month." Not "record month." The number.
2. **Screenshot attached.** A real screenshot — Stripe, dashboard, LinkedIn analytics. People trust proof they can see.
3. **Imperfect, zero-filter body.** Don't polish it. "I lied awake thinking we'd miss payroll" is better than "we faced challenges."
4. **One specific detail nobody else can copy.** The thing only you would know.

The mistake people make copying Adam: they skip the screenshot. Without it, the number is just a claim. With it, it's proof.

## Storytelling post playbook (Thursday)

The SLAY framework:

- **S — Story:** Open with something that happened. Specific, visual, in-the-moment. "I just spoke in front of 5,000 people and my hands were shaking." Not "I once gave a talk."
- **L — Lesson:** Frame as a takeaway the reader can use. Not a lesson for you. A lesson for them.
- **A — Action:** Often implicit. Sometimes a question, sometimes a CTA.
- **Y — You:** The trust signal. Vulnerability > polish.

**Pair with the "in the middle of things" rule.** Don't reminisce from a distance. Drop the reader into the moment. The TikTok-part-52 effect: people stay engaged because they're in the scene.

**Always reframe personal → universal in line 2.** "I just got engaged" alone is a wedding announcement. "I just got engaged and I never thought I'd be the kind of person who could…" works because line 2 invites projection.

## Educate post playbook (Tuesday)

The PAS framework:

- **P — Problem:** Name it in their language.
- **A — Agitate:** Make them feel it. Don't solve yet. "If you don't fix this in the next 6 months, you'll be in the same place. Your competitors are already doing X."
- **S — Solution:** Walk through the steps. Specific. Lived-experience detail. "Here's exactly how I did it, in 3 steps."

Example: Daniel Bustamante — "My phone addiction has been out of control. Over the past two weeks I've been impulsively checking LinkedIn, Substack, Gmail way more than I'd like to admit. Here's what I'm doing about it." Problem → Agitate → Solution.

## Hook architecture (every post)

First 3 lines do 3 jobs:

1. **Broad hook.** Pattern interrupt. Appeal to as many people as possible.
2. **Narrow problem.** Name the specific pain your ICP feels.
3. **Niche bridge.** Connect the broad hook + narrow problem to your specific skill or solution.

**Bad:** "Here are 5 tips for LinkedIn growth." (Generic. No pattern interrupt.)
**Good:** "98.2% of LinkedIn users will never post a single word. I'm in the 1.8%. Here's what changed." (Broad → narrow → niche.)

**Validation test:** Will someone scrolling at 11pm stop for this? If no, rewrite.

## Engagement rules

- **Like ≠ reach.** The algorithm reads comments > likes > impressions. Write for comments.
- **Never end with "Thoughts?"** It's the laziest CTA. Ask a specific question. "What's your biggest block on this?" beats "Thoughts?" 10:1.
- **Never ask for likes or follows.** It tanks engagement. Write something worth engaging with. The engagement follows.
