---
name: hormozi-offer-system
description: Build, audit, price, position, and sell a complete business offer using Alex Hormozi's Grand Slam Offer methodology (from $100M Offers / $100M Leads). Use this for market research and niche validation; building a new offer from a raw idea; auditing a weak or underperforming offer; choosing a business model; productizing a service into an offer ladder; framing delivery as DFY/DWY/DIY; reducing perceived effort or accelerating time-to-value; increasing perceived value and improving naming/framing; building an objection-killing bonus stack; setting price with anchoring and tiers; mapping and destroying objections; generating positioning angles; writing scroll-stopping hooks; building a pitch (short/medium/long); or writing landing page copy. This single skill consolidates the entire "hormozi-skills" library — originally 17 separate skills plus an orchestrator agent and five subagents — into one entry point. Trigger whenever the user wants to build, fix, price, or sell an offer, coaching program, service, or productized business.
---

# Hormozi Offer System (consolidated)

This is the complete `hormozi-skills` library folded into a single skill. The original project shipped as 17 standalone skills plus an orchestrator agent and five subagents; every one of those files is preserved **verbatim, byte-for-byte** under `references/` so nothing from the original pack was cut, shortened, or rewritten. This `SKILL.md` is the router: it tells you which reference file has the full instructions for the capability the user needs, and it reproduces the orchestrator's end-to-end pipeline logic so the whole system can run as one skill instead of six coordinated agents.

**Credit**: methodology and original skill library inspired by Alex Hormozi's *$100M Offers* and *$100M Leads*. Original multi-skill plugin ("hormozi-skills") built for coding agents by Alessandro Smedile ([github.com/alexsmedile/hormozi-skills](https://github.com/alexsmedile/hormozi-skills)), MIT licensed — full license text at `references/source-docs/LICENSE`.

## How to work this skill

1. **Identify the capability** the user needs from the index below.
2. **Read the matching reference file(s) in full before executing** — each one contains the complete original interview questions, frameworks, decision rules, and exact output format for that capability. This router summarizes them; it does not replace them.
3. If the user wants the **full pipeline** (idea → market → offer → value/pricing → sales) rather than one isolated capability, follow the "Full pipeline workflow" section below, which condenses `references/agents/hormozi-orchestrator.md`.
4. Write output to the filename the user specifies, or to the standard filename shown in the index (e.g. `OFFER.md`) in the current working directory, using the exact output format given in the reference file for that capability.

## Capability index

| Need | Read this reference | Produces |
|---|---|---|
| Research/validate a market or niche | `references/skills/market-research/SKILL.md` | `MARKET_SELECTION.md` |
| Build a new Grand Slam Offer from scratch | `references/skills/hormozi-offer/SKILL.md` | `OFFER.md` |
| One-flow idea → offer → pitch (speed path) | `references/skills/idea-to-product/SKILL.md` + `references/skills/idea-to-product/references/offer-key-points.md` | `LEAN_OFFER_SYSTEM.md` |
| Audit an existing/underperforming offer | `references/skills/audit-offer/SKILL.md` | `OFFER_AUDIT.md` |
| Generate alternative positioning angles | `references/skills/offer-angles/SKILL.md` | `OFFER_ANGLES.md` |
| Improve naming/packaging/perceived value | `references/skills/value-perception/SKILL.md` | `VALUE_PERCEPTION.md` |
| Build an objection-killing bonus stack | `references/skills/bonus-stack/SKILL.md` | `BONUS_STACK.md` |
| Set price (anchoring, tiers, justification) | `references/skills/pricing-strategy/SKILL.md` | `PRICING.md` |
| Map and neutralize objections | `references/skills/objection-destroyer/SKILL.md` | `OBJECTIONS.md` |
| Choose the business model (subscription, high-ticket, hybrid, DFY/DWY/DIY) | `references/skills/business-model/SKILL.md` | `BUSINESS_MODEL.md` |
| Frame delivery as DFY / DWY / DIY tiers | `references/skills/dfy-dwy-diy/SKILL.md` | `DELIVERY_MECHANISM.md` |
| Turn a service into a scalable product + offer ladder | `references/skills/productize/SKILL.md` | `PRODUCTIZATION.md`, `OFFER_LADDER.md`, `REVENUE_FLOW.md` |
| Reduce time-to-first-result / onboarding friction | `references/skills/value-accelerator/SKILL.md` | `TIME_TO_VALUE.md` |
| Reduce perceived effort/complexity in the offer | `references/skills/effort-reduction/SKILL.md` | `EFFORT_REDUCTION.md` |
| Generate scroll-stopping hooks | `references/skills/hormozi-hooks/SKILL.md` + `references/skills/hormozi-hooks/references/hormozi-style-hooks.md` | `HOOKS.md` |
| Build a pitch (short/medium/long) | `references/skills/hormozi-pitch/SKILL.md` | `PITCH.md` |
| Write landing page copy | `references/skills/landing-page-copy/SKILL.md` | `LANDING_PAGE.md` |
| Scaffold this content as its own Claude Code/Codex plugin repo | `references/skills/create-plugin/SKILL.md` | plugin repo structure |

Each `references/skills/<name>/SKILL.md` is self-contained: purpose, when to use it, inputs, step-by-step assistant behavior, exact `## Output Format`, decision rules, and success criteria — read it directly rather than relying on this summary table.

## Full pipeline workflow (condensed from the original orchestrator)

The original system used one orchestrator agent delegating to five subagents (`sub-market`, `sub-offer`, `sub-value`, `sub-pricing`, `sub-sales`). A single skill can't spawn separate agents, so run the same phases yourself, in the same order, reading each subagent's full brief-handling logic from `references/agents/` as you reach it. The complete original text — including the exact interview script, all five stage definitions, the subagent brief template, and the `SUMMARY.md` template — lives in `references/agents/hormozi-orchestrator.md`; `references/agents/sub-*.md` hold each subagent's own detailed behavior.

**Phase 1 — Intake.** Accept anything: a raw idea, a brain dump, an existing offer file, a sales page, a few sentences. Read any files referenced. Summarize what you understood in 3–5 specific bullet points before moving on.

**Phase 2 — Interview.** Ask one question at a time, always offering your best-guess recommended answer so the user can just confirm/correct. Stop once you know: WHO (specific target customer), PAIN (urgent problem), OUTCOME (measurable result), STAGE (idea / rough offer / live product), DELIVERY (DFY/DWY/DIY or "help me decide"), CONSTRAINTS (time/budget/energy), GOAL (what this session should produce), PROOF (existing results or none). Skip any question you can already answer from context, and state the assumption instead.

**Phase 3 — Stage detection.** Classify into one of five stages and tell the user what will run before proceeding:
- **Stage A — Idea only**: no validated market, no offer yet → run market research → offer → value → pricing → sales, full stack.
- **Stage B — Offer exists but isn't converting**: audit + value work first, then rebuild the offer, reprice, redo sales assets.
- **Stage C — Offer is solid, needs sales assets only**: skip straight to pitch, hooks, landing page.
- **Stage D — Service business wants to scale**: pricing/productization first, then updated offer angles, then sales assets.
- **Stage E — Custom/mixed**: pick only the specific capabilities that close the gaps this user actually has, and say why.

**Phase 4 — Execution order (dependencies).** Market research → offer → (value work and pricing can run in parallel once an offer exists) → sales assets (pitch/hooks/landing page need the finished offer + value layer). Never build sales copy before the offer itself is settled; never audit an offer that doesn't exist yet.

**Phase 5 — Summary.** After the relevant capabilities are done, produce a `SUMMARY.md` with: the offer in one paragraph, a table of key decisions made (target customer, core problem, dream outcome, delivery model, price point, offer name, guarantee) and why, the top 3 highest-leverage actions to take right now, an index of every file produced and when to use it, where to pick up next session, and the single best hook to use today.

**Operating rules that carry over from the orchestrator, regardless of stage:** interview one question at a time, never as a dumped list; always offer a recommended answer; stop interviewing once you have enough rather than over-asking; challenge weak inputs directly ("that's too broad — here's a sharper version") instead of politely running with them; if the user gives very little to work with, state your assumptions plainly, ask only the 2–3 most important remaining questions, and offer 2–3 possible directions; if the user seems overwhelmed, collapse to Stage C or to the single most impactful capability and explain why that's the best first move; act as a strategic partner, not a form-filler.

## Core frameworks (quick reference — full depth is in each skill's reference file)

- **Grand Slam Offer** — an offer specific and valuable enough that the prospect feels foolish saying no. Built from: target avatar → obstacles standing between them and the outcome → a solution mapped to each obstacle → a value stack → pricing → a guarantee → positioning/naming.
- **Value Equation** — perceived value ≈ (Dream Outcome × Perceived Likelihood of Achievement) ÷ (Time Delay × Effort & Sacrifice). Every capability in this skill pushes on one of these four levers: make the outcome bigger/clearer, make success feel more certain, make it faster, or make it feel easier.
- **Obstacle → solution reversal** — list every reason the avatar fails to get the outcome on their own, then design a specific deliverable that removes each one; this becomes the value stack.
- **Bonus/value stacking** — solve for each obstacle individually rather than one monolithic deliverable, so the stack's perceived value is visibly greater than the price.
- **Guarantee design** — unconditional, conditional, or effort-based guarantees that reduce perceived risk without needing to touch price.
- **Price anchoring** — price is justified by the value stack and outcome, not by cost-plus or competitor matching.
- **Hook architecture** — pattern interrupt, identity call-out, outcome-led, and curiosity-led hooks, always paired with speed and effort-reduction signals.

## What's in `references/`

```
references/
├── skills/            17 original skills, each folder's SKILL.md (and any of its own
│                       references/ subfiles) copied unmodified from the source pack
├── agents/             hormozi-orchestrator.md + the 5 sub-*.md subagent definitions,
│                       unmodified
├── source-docs/        original README.md, CLAUDE.md, TODO.md, LICENSE, and the
│                       plugin/marketplace manifest files, for provenance
└── articles/            the pack's included article on orchestration vs. one-shot prompting
```

Nothing from the uploaded pack was omitted — only the empty placeholder `input/` and `output/` directories from the original repo (a single `.gitkeep` and a "drop your files here" stub, no real content) were left out, since this skill writes its own output wherever the user is working.
