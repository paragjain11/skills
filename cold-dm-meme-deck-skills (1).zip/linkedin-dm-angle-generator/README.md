# LinkedIn DM Angle Generator

A Claude.ai skill that generates a numbered bank of psychologically sharp conversation-opening angles for LinkedIn cold DMs — custom to your ICP, offer, and niche. It does not write DM copy.

---

## What It Does

Cold outreach is a creative job, not a template job. Frameworks get saturated. The same curiosity-gap opener, the same pain-point structure, the same CTA formula — they've been sent so many times that LinkedIn has conditioned prospects to dismiss them automatically.

This skill replaces frameworks with deep generative thinking. It runs your ICP and offer through 12 psychological territories — each rooted in specific persuasion research — and surfaces angles you would not think of on your own. The output is raw material: a bank of entry points you use to write your own messages.

**What you get:**
- A numbered bank of conversation-opening angles
- Each angle includes: the angle itself, the psychological mechanism behind it, the territory it belongs to, and a usage note on what DM it opens and what CTA naturally follows
- Post-delivery options to go deeper, generate more, or think through DM structure

**What you do not get:**
- DM copy
- Templates
- Frameworks
- Anything generic

---

## When to Invoke

Use this skill when you want to build a bank of LinkedIn outreach angles before writing messages.

Trigger phrases:
- "generate LinkedIn angles"
- "help me with cold DM angles"
- "give me LinkedIn outreach angles"
- "create DM opening angles"
- "I need angles for cold outreach"
- "build me an angle bank"
- "LinkedIn cold message angles"
- "angle bank for LinkedIn"
- "cold outreach angles"
- "help me write cold DMs"

---

## Required Inputs

The skill collects 6 inputs before generating anything:

| # | Field | What you provide |
|---|-------|-----------------|
| 1 | Offer | What you sell, who it's for, what problem it solves, what result it produces |
| 2 | ICP Demographics | Job title, company size, industry, seniority, geography if relevant |
| 3 | ICP Psychographics | Daily frustrations (specific moments), fears, desires, professional identity, what they brag about, what they read, what keeps them up |
| 4 | Niche Context | What's happening in this market right now — shifts, conversations, ambient anxiety or excitement |
| 5 | Number of Angles | How many you want |
| 6 | Angle Types | Which of the 12 psychological territories to explore (or "all") |

If your psychographic data is thin, the skill will ask follow-up questions before generating. This is intentional — the quality of the output depends entirely on the depth of the input.

---

## The 12 Psychological Territories

| Territory | Psychological Basis |
|-----------|-------------------|
| Pain | Pattern interrupt + self-referential processing (cocktail party effect) |
| Desired Outcome | Self-discrepancy theory (Higgins) + fantasy realization |
| Humor | Benign violation theory (McGraw & Warren) + incongruity resolution |
| Absurdity | Incongruity resolution + surprise arousal state |
| Provocation | Cognitive dissonance (Festinger) + Zeigarnik effect |
| Curiosity | Loewenstein's information gap theory |
| Identity | Social identity theory (Tajfel & Turner) + professional identity performance |
| Fear | Prospect theory (Kahneman & Tversky) + anticipatory regret + challenge appraisal |
| Social Dynamics | Descriptive vs. injunctive norms + peer comparison (optimal gap) |
| Contrarian | Cognitive dissonance + pattern interrupt |
| Industry Observation | Self-discrepancy + approach/avoidance motivation systems (BAS/BIS) |
| Ambition | Self-determination theory (Deci & Ryan) + fantasy realization |

---

## What the Output Looks Like

Each angle in the bank follows this format:

```
1. [THE ANGLE]

   The angle itself — a specific question, observation, statement, or premise.
   Not a full DM. The entry point into the conversation.
   Reads like something a sharp human being would actually say.

   ↳ Psychological mechanism: One sentence on what this activates and why it works on this ICP
   ↳ Territory: Which of the 12 categories
   ↳ Usage note: What DM this opens and what CTA would naturally follow
```

Every angle passes through 7 quality filters before being included:

1. **Specificity test** — could only apply to this exact ICP
2. **Template test** — doesn't follow a recognizable formula
3. **Buzzword test** — plain English only
4. **Natural next step test** — obviously opens a specific conversation
5. **LinkedIn conditioning test** — doesn't trigger "sales message" pattern recognition
6. **Self-referential test** — feels like it was written about one specific person
7. **Humor test** (for humor/absurdity angles) — would a smart person in this role smile, not roll their eyes

---

## Follow-Up Options

After delivery, the skill offers three options:

**A — Go deeper on a specific angle**
Push it further, explore variants, stress-test it against the ICP.

**B — Generate a second batch focused on a specific territory**
More angles from a different psychological entry point within that territory.

**C — Think through what DM naturally follows from a selected angle**
Work through message structure together — without the skill writing the DM for you.

---

## How to Deploy to Claude.ai

1. **Create or open a Claude.ai Project**

2. **Add the skill instructions:**
   - Open Project Settings → Instructions
   - Paste the full contents of `SKILL.md` (including the frontmatter) into the Instructions field

3. **Trigger the skill** by saying any of the trigger phrases above, or by describing what you need

No MCP tools required. No knowledge documents to upload. The skill is fully self-contained.

---

## Skill Structure

```
consultative-linkedin-cold-dm/
├── SKILL.md       # Full skill definition — paste into Claude.ai Project Instructions
└── README.md      # This file
```

---

## What This Skill Explicitly Does Not Do

- Does not write DM copy
- Does not produce frameworks or templates
- Does not generate output that could apply to any B2B company
- Does not proceed without complete, confirmed inputs
- Does not generate angles with thin psychographic data
- Does not use buzzwords, corporate language, or marketing copy
