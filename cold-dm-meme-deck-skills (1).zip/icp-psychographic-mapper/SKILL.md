---
name: icp-psychographic-mapper
description: Generate precise, research-backed psychographic profiles of Ideal Customer Profiles (ICPs). Builds a real human persona — not a job title with adjectives. Grounded in actual cultural context (location, generation, industry), real language from forums and social media, and specific behavioral patterns. Workflow requires user approval of research questions before proceeding. Output is bullet-pointed, precise, and contains zero filler.
---

# ICP Psychographic Mapper

## Purpose

Build a psychographic persona that reads like a real human being — not a marketing avatar. The person reading this profile should think: *"I know this person. I've met them."* Not: *"This could be anyone."*

The profile must be:
- **Culturally grounded** — if the ICP is a 38-year-old American CMO, their hobbies, references, anxieties, and media diet must reflect American professional culture of that generation specifically
- **Precise** — every bullet is a concrete, specific, usable fact. No filler. No generic statements that apply to all humans
- **Evidence-based** — every claim traces back to research: real quotes, real forum threads, real behavior patterns observed online
- **Approval-gated** — user must approve or modify the research questions before research begins

---

## Workflow

### Phase 1: Input Collection

Ask the user for:

1. **ICP Demographics** — job title(s), company size, industry/niche, location (country + city/region if known), seniority/experience level, age range
2. **Product Details** *(optional but recommended)* — what you sell, who the vendor is, what category it fits in. Needed to accurately build the "Feelings About Vendors Like You" section

If the user skips product details, note it and proceed — mark the vendor feelings section as "incomplete without product context."

---

### Phase 2: Question Generation (Approval Gate)

Before doing any research, generate a set of targeted research questions for each category below.

**Goal of this phase:** Surface the specific questions that will make this persona *real and specific* — not generic. Questions should reflect the ICP's location, generation, industry, and role pressure.

Present all questions to the user, organized by category. Explicitly ask:
> "Review these questions. Add, remove, or modify anything before I proceed to research. Once you approve, I'll go research each one."

Do not proceed to Phase 3 until the user approves.

---

#### Question Categories and What to Ask

For each category, generate 3–5 sharp, specific questions. Not broad. Not meta. Questions a journalist would ask, not a marketer.

---

**Category 1: Identity & Personality**

Who is this person as a human being — their character, how they carry themselves, what drives them psychologically?

Generate questions like:
- What personality archetype does this role tend to attract? (Builder, operator, strategist, optimizer?)
- Are they introverted or extroverted in a professional setting? How does that show up in how they work?
- How do they handle pressure and ambiguity? Do they lean into control or adapt?
- What is their relationship with status — do they seek it, deflect it, or deny caring about it?
- What do people who work with them say about them (positive and negative)?

---

**Category 2: Hobbies & Activities**

What do they actually *do* when they're not working?

Generate questions like:
- What physical activity or sport is most common in this demographic at this career stage?
- Do their hobbies skew solo (running, cycling, cooking) or social (golf, team sports, book clubs)?
- Is there a hobbyist identity they've built around something outside work?
- What does a typical Saturday morning look like for this person?
- Do they have a side project, creative outlet, or passion project that they don't monetize?

---

**Category 3: Cultural & Generational Influences**

What shaped them? What cultural references, events, and generational context do they carry?

Generate questions like:
- What generation are they (Millennial, Gen X, Elder Millennial)? What major events shaped their professional worldview?
- What pop culture, music, sports teams, or media defined their formative years?
- What is the typical political and social worldview of this demographic and location?
- How does their generation relate to work — hustle culture, work-life integration, loyalty to employers?
- What American cultural norms around ambition, success, and identity are embedded in how they operate?

*Note: If location is outside the US, adjust questions to reflect that country's specific cultural context.*

---

**Category 4: Interests**

What topics captivate them beyond professional obligation?

Generate questions like:
- What do they read or watch when it has nothing to do with their job?
- Are they drawn to systems thinking, philosophy, history, sports analytics, finance?
- What's the crossover between their intellectual interests and their professional worldview?
- Is there a subject they'd spend a weekend learning about if they had no other obligations?

---

**Category 5: Values & Beliefs**

What are the principles they won't compromise on — at work and in life?

Generate questions like:
- What does "great work" look like to this person? What would embarrass them professionally?
- What do they think is fundamentally broken in their industry?
- How do they define success — and has that definition changed in the last 5 years?
- Where do they draw ethical lines — in how they sell, lead, or operate?
- What is their relationship with ambition — is it a public identity or a private driver?

---

**Category 6: Opinions & Worldview**

What do they believe strongly enough to defend publicly?

Generate questions like:
- What industry trend do they think is overhyped? What's underrated?
- What do most people in their role get wrong?
- What's a contrarian take they hold that they'd only share with trusted peers?
- How do they see their competitive landscape — are they optimistic or bearish?
- What do they think about how their category is evolving?

---

**Category 7: Brand Affinities**

What companies, tools, and brands do they identify with?

Generate questions like:
- What B2B tools do they swear by and recommend without being asked?
- What consumer brands reflect their lifestyle — clothes, gear, food, car?
- What companies do they hold up as a model for how to build, market, or operate?
- What draws them to a brand — design, values alignment, peer reputation, or proven utility?
- What brands do they avoid and why?

---

**Category 8: Media & Information Diet**

Where do they actually spend their attention?

Generate questions like:
- Which specific podcasts do they listen to regularly — not categories, actual show names?
- Which newsletters do they actually open vs. archive unread?
- Which social platforms do they use and how — scrolling, posting, community participation?
- Which specific people do they follow and trust as thought leaders in their space?
- What events or conferences do they attend in person?
- When does content consumption fit into their day — commute, workout, Sunday morning?

---

**Category 9: Needs (External)**

What do they functionally, rationally need right now?

Generate questions like:
- What is the #1 operational or strategic gap creating pressure in their role right now?
- What do they need in the next 90 days to be seen as successful internally?
- What's missing from their current tech stack or team that limits their output?
- What organizational constraints (budget, headcount, misalignment) are blocking them?

---

**Category 10: Wants (Internal)**

What do they want at the psychological level — beneath what they'd say in a job interview?

Generate questions like:
- What version of themselves are they trying to become in the next 3 years?
- What recognition or status are they hungry for that they wouldn't admit publicly?
- What does "winning" feel like to them — not the metric, the feeling?
- What kind of leader or professional do they want to be known as?

---

**Category 11: Feelings About Vendors (The Seller)**

How do they feel about people selling products like yours?

Generate questions like:
- What's their default emotional posture toward vendors in this category — open, skeptical, burned, curious?
- What do salespeople in this space do that triggers immediate distrust?
- What would shift their posture from skeptical to genuinely interested?
- What does good vs. bad cold outreach look like to them specifically?
- What emotional experience do they want from a vendor relationship vs. what they usually get?

---

**Category 12: Hopes**

What near-term outcomes are they optimistic about?

Generate questions like:
- What are they most excited to prove in the next 12 months?
- What does "best case scenario" look like for their company and their role in 2 years?
- What personal or career milestone are they working toward?

---

**Category 13: Dreams**

What are the bigger, quieter aspirations they don't say out loud?

Generate questions like:
- What would they build or become if their current role disappeared tomorrow?
- Is there a "second act" they think about — founding something, advising, writing, changing industries?
- What does success look like at 50 or 55 when they look back on this period?
- What's the version of impact they'd create if constraints didn't exist?

---

**Category 14: Fears**

What keeps them up? What are they protecting against?

Generate questions like:
- What professional failure would be most damaging to their identity — not just their career?
- What market or industry shift are they most afraid of being caught unprepared for?
- What's the fear they carry that they would never admit in a board room or team meeting?
- How does burnout or personal life pressure interact with how they make decisions at work?
- What would cause the CEO to lose confidence in them specifically?

---

### Phase 3: Deep Research

After user approval, conduct research to answer every approved question. Do not skip questions.

**Research sources (use all that are relevant):**
- Reddit — subreddits where this ICP congregates (r/marketing, r/sales, r/startups, role-specific subs)
- LinkedIn — public posts, comment threads, discussions from people matching the ICP
- X (Twitter) — discussions, threads, public takes from this demographic
- YouTube — video content, comment sections on relevant channels
- Google — interviews, case studies, blog posts written by or about this ICP demographic
- Quora — questions asked by and answered by this type of person
- Industry-specific forums — Indie Hackers, Product Hunt, Pavilion, Exit Five, Slack archives, etc.
- Reports and surveys — published data on this role/industry (CMO surveys, State of X reports, etc.)

**For each question answered, extract:**
- Direct quotes from real people (name, platform, context)
- Observed behavioral patterns (what they do, not just what they say)
- The exact language and terminology they use — not your paraphrase
- Emotional tone — especially around vendors, stress, ambition, and identity

**Research rounds:**
- Round 1: Answer all approved questions
- Round 2 (if needed): Fill gaps, find contradictory evidence, deepen weak sections

---

### Phase 4: Persona Synthesis

Build the profile from the research. Do not build from assumptions. Every claim must trace back to research.

**Output format rules:**
- Use bullet points throughout — no long paragraphs
- Every bullet is a specific, concrete fact. Zero filler. Zero statements that apply to all humans
- If a bullet is a claim without research support, mark it `[inferred]` so the user knows
- Use the ICP's actual language — lift phrases directly from quotes where possible
- Ground cultural references in the person's real context (generation, location, industry)

**Persona construction rules:**
- Give the persona a name, age, city, and one-line identity statement at the top
- Write each section as if describing a specific real person, not a job title
- Include contradictions and tensions — real humans are not consistent
- Include details that are NOT about work — hobbies, relationships, daily routines, weekend patterns
- If the ICP is American, their references must be American: sports teams, cultural events, political context, generational touchstones, regional identity
- If another country/region, same rule applies — ground them in their actual cultural context

---

### Phase 5: Output Structure

Deliver the final profile in this order:

---

**Persona Header**
- Name (fictional but realistic for their demographic)
- Age
- City / Region
- One-line identity: who they are in one sentence, not their job title

---

**1. Identity & Personality**
- Core personality traits visible at work and outside it
- How they handle pressure, ambiguity, conflict
- Their relationship with status and recognition
- What people say about them — accurately, not charitably

---

**2. Hobbies & Activities**
- Specific activities with frequency and context
- Solo vs. social split
- What their Saturday morning looks like
- Any side projects or non-work creative outlets
- How hobbies connect to stress relief, identity, or social life

---

**3. Cultural & Generational Context**
- Generation and what events/culture shaped them
- Regional American (or local) cultural identity
- Political and social worldview as it intersects with professional identity
- Generational relationship with work, ambition, loyalty, and work-life balance
- Pop culture touchstones — music, sports, movies, TV — that they grew up with and still reference

---

**4. Interests**
- Topics they follow out of genuine curiosity (not job necessity)
- What they'd learn if they had a free weekend
- Intellectual crossovers that inform how they think professionally

---

**5. Values & Beliefs**
- What great work looks like to them — and what would embarrass them
- What's broken in their industry (the opinion they hold and won't back down from)
- How they define success now vs. 5 years ago
- Ethical lines they don't cross
- Their relationship with ambition — public or private

---

**6. Opinions & Worldview**
- Contrarian takes they'd defend in public
- What they think most people in their role get wrong
- Their view on trends — what's overhyped, what's underrated
- How they see the competitive landscape they operate in

---

**7. Brand Affinities**
- B2B tools they trust and recommend by name
- Consumer brands that reflect their lifestyle (clothes, gear, food, car)
- Companies they hold up as models for GTM, culture, or product
- What triggers brand loyalty for them vs. what makes them walk
- Brands they actively avoid and why

---

**8. Media & Information Diet**
- Specific podcasts (named) — which ones they actually finish vs. skip
- Specific newsletters (named) — which ones they open vs. archive
- Social platforms with usage pattern (lurker, poster, community member)
- Specific thought leaders they follow and trust (named)
- Events they attend in person
- When in the day/week they consume what type of content

---

**9. Needs (External)**
- What they need in the next 90 days to be seen as winning internally
- The specific operational or strategic gap creating the most pressure right now
- What's missing from their tech stack or team
- Organizational constraints blocking them (budget, headcount, alignment)

---

**10. Wants (Internal)**
- The version of themselves they're trying to become
- The recognition or status they're hungry for (the real version, not the polished answer)
- What "winning" feels like — not the metric, the emotion
- What kind of professional reputation they're building

---

**11. Feelings About Vendors (The Seller)**
- Default emotional posture toward this vendor category
- Specific behaviors that trigger immediate distrust or disengagement
- What earns a second look — specifically
- What good vs. bad cold outreach looks like to them
- The emotional experience they want from a vendor vs. what they usually get

---

**12. Hopes**
- What they're most excited to prove in the next 12 months
- Best-case scenario for their company and their role in 2 years
- Personal or career milestone they're working toward

---

**13. Dreams**
- The bigger, quieter ambition they don't share in board meetings
- Second act they think about — founding something, advising, writing, exiting
- What success looks like at 50–55 looking back at this period
- The version of impact they'd create with zero constraints

---

**14. Fears**
- The professional failure that would damage their identity — not just their career
- The market shift they're most afraid of being caught unprepared for
- The fear they'd never say out loud in a board room
- How burnout and personal pressure interact with their professional decisions
- What would cause leadership to lose confidence in them specifically

---

**15. Research Evidence**
- Direct quotes used, with source (person, platform, context)
- Key data points and statistics with source
- Behavioral patterns observed across multiple sources
- Any inferred claims flagged as `[inferred]`

---

## Quality Rules (Non-Negotiable)

1. **No generic bullets.** If a bullet could describe 80% of professionals, delete it or make it specific
2. **Cultural grounding is mandatory.** A US-based 38-year-old Millennial CMO has specific cultural DNA. It must show up in the profile — sports references, political awareness, generational relationship with work, regional identity if applicable
3. **Real language only.** Use the words and phrases the ICP actually uses, lifted from research. Do not translate into marketing language
4. **Contradictions are features.** Real humans are inconsistent. Include tensions — the CMO who believes in quality outreach but works at an AI SDR company. The founder who claims not to care about status but checks their LinkedIn analytics daily
5. **Every section has personality.** The profile should read like a character brief for a film, not a job description
6. **Vendor feelings section is the most important section for outreach.** Spend the most research effort here. Be brutally specific about what triggers distrust and what earns attention
7. **Approval gate is mandatory.** Do not skip Phase 2. Do not proceed to research until the user explicitly approves or modifies the questions
