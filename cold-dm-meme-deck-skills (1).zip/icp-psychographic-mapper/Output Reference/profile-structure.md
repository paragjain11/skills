# ICP Psychographic Profile Structure

This document provides the complete structure template for the psychographic profile output.

## Template Structure

### Executive Summary
A 2-3 paragraph overview capturing the essence of who this person is — their lifestyle, inner world, and relationship with the world around them. Paint a picture of a real, complex human being, not a job title.

---

### 1. HOBBIES & ACTIVITIES

What does this person actively *do* outside of work? What fills their time, their weekends, their physical and creative energy?

- Specific hobbies and recreational activities (sports, creative pursuits, collecting, etc.)
- How frequently they engage in these activities
- Whether hobbies are solo or social
- Physical activities and fitness habits
- Side projects or passion projects
- How hobbies connect to their broader identity (e.g., "running is how I decompress from work stress")

---

### 2. INTERESTS

What topics, domains, and ideas captivate their attention even when there's no direct utility?

- Intellectual or cultural interests (technology, philosophy, history, etc.)
- Industry topics they follow out of genuine curiosity, not just job necessity
- Content they consume for pleasure vs. professional development
- Adjacent fields or crossover interests
- Things they'd learn more about if they had unlimited time

---

### 3. VALUES & BELIEFS

What principles guide their decisions and define who they are at their core?

- Professional values (what they believe great work looks like)
- Personal values (family, integrity, ambition, independence, etc.)
- Beliefs about their industry — what's right, what's broken, what needs to change
- Views on success, work-life balance, and what a life well-lived looks like
- Ethical lines they won't cross professionally or personally
- Beliefs about AI, technology, and the future of work

---

### 4. OPINIONS & WORLDVIEW

How do they see the market, their industry, and the world at large?

- Strong opinions they hold about their field (and would defend publicly)
- Views on industry trends — what they think is overhyped vs. underrated
- How they see the competitive landscape and their place in it
- Opinions on leadership, management, and organizational culture
- Political or social worldview as it intersects with their professional identity
- What they think most people in their industry get wrong

---

### 5. BRAND AFFINITIES

What brands, products, and companies do they trust, admire, or identify with?

- B2B tools and software they swear by and recommend to peers
- Consumer brands that reflect their lifestyle and values
- Companies they look up to as a model (for culture, marketing, GTM, etc.)
- Brands they avoid and why
- What draws them to a brand: design, values alignment, peer reputation, utility?
- How brand loyalty forms for them (earned through experience, peer recommendation, etc.)

---

### 6. MEDIA CHANNELS

Where do they actually spend their attention? What formats and platforms shape their information diet?

- Primary social platforms (LinkedIn, X/Twitter, YouTube, Reddit, etc.) and how they use each
- Podcasts they listen to consistently (with specific show names)
- Newsletters they actually open and read
- Communities and Slack groups they participate in
- Events and conferences they attend
- Influencers, creators, or thought leaders they follow and trust
- What they read long-form vs. skim vs. save-but-never-finish
- When and how content fits into their daily routine (commute, workout, wind-down)

---

### 7. NEEDS (EXTERNAL)

What do they functionally, practically need in their professional and personal life? These are the rational, surface-level requirements.

- Professional needs: tools, resources, information, skills, support
- Organizational needs: budget, headcount, alignment, clarity
- Operational needs: efficiency, speed, reliability, integration
- Personal needs: time, income, stability, recognition
- What they urgently need right now vs. what they'll need in 6–12 months
- Gaps between what they have and what they need to succeed

---

### 8. WANTS (INTERNAL)

What do they deeply desire beneath the surface-level needs? These are the emotional and psychological drivers.

- The version of themselves they're trying to become
- Status, respect, or recognition they hunger for
- Control, autonomy, or freedom they're striving toward
- The feeling they want to have at work (purpose, momentum, confidence)
- What kind of leader or professional they want to be seen as
- The deeper "why" behind their stated professional goals
- What they want their legacy or reputation to be

---

### 9. FEELINGS (ABOUT PEOPLE LIKE ME — THE VENDOR/SELLER)

How do they feel about people who sell products or services like yours? What emotional baggage do they bring to vendor interactions?

- General disposition toward vendors in your category (skeptical, open, burned, cautious)
- Emotional history with similar products — previous disappointments or wins
- How they feel when they receive cold outreach in your space
- What salespeople or marketers in your category typically do that annoys them
- What earns their trust and shifts their emotional posture
- The emotional experience they *want* from a vendor relationship vs. what they usually get
- Red flags that trigger immediate distrust or disengagement

---

### 10. HOPES

What are they optimistic about? What possibilities excite them about the future?

- Hopes for their company's trajectory (growth, exit, impact)
- Hopes for their own career — where they want to be in 3–5 years
- Hopes for their industry — what they want the future of their market to look like
- What they're most excited to try, build, or become
- The "best case" version of their professional reality they're working toward
- Personal hopes — for their family, finances, lifestyle

---

### 11. DREAMS

What are the bigger, longer-horizon aspirations that they might not say out loud in a board meeting?

- The ambitious outcome they quietly believe is possible but don't talk about publicly
- Career moonshots: founding something, leading a major exit, building a category
- Personal dreams: financial independence, lifestyle design, a second act
- The version of impact they'd create if constraints didn't exist
- What success looks like when they're 55 and looking back
- Fantasies about how their industry could be transformed if done right

---

### 12. FEARS

What keeps them up at night? What are they trying to avoid, protect against, or escape?

- Professional fears: becoming irrelevant, missing a market shift, pipeline collapsing
- Identity fears: not being seen as credible, losing the CEO's confidence, getting passed over
- Organizational fears: losing key team members, budget cuts, misalignment with founders
- Market fears: commoditization of their product, buyer skepticism, competitive threats
- Personal fears: burnout, financial instability, work crowding out family
- The fear they'd never say out loud but that shapes many of their decisions

---

## Formatting Guidelines

- Write in a narrative, humanizing style — paragraphs over bullet points where possible
- Be specific and concrete; avoid generic statements that could apply to anyone
- Ground every section in real research findings and direct quotes where available
- Show the human complexity — contradictions, nuance, and tension are features, not bugs
- Use language this ICP would actually recognize and use themselves
- Total length: 3000–5000 words
- End with a **Research Evidence** section listing key quotes, data points, and sources used
