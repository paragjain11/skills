# Format & Caption Prompt Library

Derived from the proven 34-meme bank in `reference-library/`. Each entry:
the situation, the layout to run, and the fill-in prompt. [brackets] = swap
in the prospect's real detail. Keep slots under ~10 words.

Layout column = the argument for make_meme.py. Text slots are in the exact
order the script expects.

## Situation: Opened but No Reply

**Drake** (layout: drake, 2 slots)
Joke: rejecting the normal thing, smugly preferring the absurd thing.
Prompt: slot1 = "replying to my message" / slot2 = "[the specific absurd
thing they did instead: opening it N times and saying nothing / forwarding
it to no one / reading it at 2am]"

**Gru's Plan** (layout: gru, 4 slots)
Joke: plan goes right until step 3, which repeats as the failure.
Prompt: slot1 = "send the perfect [message/deck]" / slot2 = "[they open it]"
/ slot3 = "[opens it again]" / slot4 = repeat slot3 verbatim.
Variation from bank: slot2-4 can escalate: "opens it" / "opens it again" /
"opens it again".

**Anakin Padme** (layout: anakin, 3 slots)
Joke: hopeful assumption, unsettling silence.
Prompt: slot1 = "[the thing that happened: opened it / clicked the link]" /
slot2 = "so they'll reply right?" / slot3 = "they'll reply... right?"

**Waiting Skeleton** (layout: topbottom, 2 slots, templates/skeleton.jpg)
Joke: waited so long, became a skeleton.
Prompt: slot1 = "me waiting for them" / slot2 = "to [the thing: reply to a
message they read N days ago / say literally anything]"
Bank variation: slot1 = "they said '[their exact non-committal reply]'" /
slot2 = "with their whole chest and went quiet"

## Situation: Not Opened yet

**Waiting Skeleton** (layout: topbottom, 2 slots)
Prompt: slot1 = "me waiting for them" / slot2 = "to open a message i sent
[N] days ago"

**This Is Fine** (layout: fine, 1 slot)
Joke: everything burning, pretending it's fine. The "THIS IS FINE" punchline
is baked into the right panel; you only write the left-panel setup.
Prompt: slot1 = "they haven't opened it in [N] days" (or any single line
naming the quietly-on-fire situation)

**Bernie** (layout: topbottom, 2 slots, templates/bernie.jpg)
Joke: politely asking again for the same thing.
Prompt: slot1 = "i am once again asking" / slot2 = "for you to open the
[deck/message] i [built you / sent Tuesday]"

## Situation: Replied Then Went Cold

**Gru's Plan** (layout: gru, 4 slots)
Prompt: slot1 = "they reply" / slot2 = "says they're interested!" /
slot3 = "says [their exact phrase: let's connect soon!]" / slot4 = repeat
slot3 verbatim.
The kill shot is using their actual words in slots 3-4.

**Anakin Padme** (layout: anakin, 3 slots)
Prompt: slot1 = "[what they said: 'this looks great']" / slot2 = "so we're
booking that call right?" / slot3 = "we're booking it... right?"

**Drake** (layout: drake, 2 slots)
Prompt: slot1 = "booking the call we talked about" / slot2 = "[what they
did: liking my message and evaporating]"

## Situation: No one Showed up at the call

**UNO Draw 25** (layout: uno, 2 slots)
Joke: choosing absurd cost over the simple thing.
Prompt: slot1 = "you could just show up to the call you booked with me" /
slot2 = "Prospects" (or their first name for a 1:1 send — gentlest version)

**Waiting Skeleton** (layout: topbottom, 2 slots)
Prompt: slot1 = "me on our zoom call" / slot2 = "[N] minutes past the time
you picked"

## Caption rules (apply to every format)

1. The prospect's REAL detail is the joke. "Opened it 6 times" beats any
   generic line. Pull the detail from what the user tells you about the
   prospect's behavior.
2. Slots under 10 words. The script wraps, but long slots kill the read.
3. Their exact words, quoted back, are the strongest material for the
   went-cold formats.
4. Lowercase reads more casual and human for DMs; keep proper nouns capped.
5. If it needs explaining, rewrite it.
