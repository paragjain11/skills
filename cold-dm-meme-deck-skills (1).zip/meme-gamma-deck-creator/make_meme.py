#!/usr/bin/env python3
"""
make_meme.py — caption blank meme templates locally. No Imgflip account needed.

Usage:
  python3 make_meme.py <layout> <output.jpg> "text1" ["text2" "text3" "text4"]

Layouts and their text slots (in order):
  drake      2 texts: reject (top), prefer (bottom)          -> templates/drake.jpg
  gru        4 texts: plan step 1, 2, 3, 3-repeated          -> templates/gru.jpg
  anakin     3 texts: statement, hopeful q, worried q        -> templates/anakin.png
  uno        2 texts: the ask (card), who's choosing (label) -> templates/uno.jpg
  fine       1 text: left-panel line ("THIS IS FINE" is baked
             into the right panel)                          -> templates/this-is-fine.jpg
  topbottom  2 texts: top line, bottom line (white w/ black
             stroke, works on ANY image) — pass template path
             as 5th arg or defaults to templates/skeleton.jpg

Examples:
  python3 make_meme.py drake out.jpg "replying to my message" "opening it 6 times and saying nothing"
  python3 make_meme.py topbottom out.jpg "me waiting for them" "to open a message i sent 9 days ago" templates/skeleton.jpg
"""
import sys, os, textwrap
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def load_font(size):
    return ImageFont.truetype(FONT_BOLD, size)

def draw_wrapped(d, text, cx, cy, max_chars, font, fill='black', stroke=0, stroke_fill='black', line_h=None):
    lines = textwrap.wrap(text, width=max_chars)
    lh = line_h or int(font.size * 1.25)
    y = cy - len(lines) * lh // 2
    for line in lines:
        w = d.textlength(line, font=font)
        d.text((cx - w / 2, y), line, font=font, fill=fill,
               stroke_width=stroke, stroke_fill=stroke_fill)
        y += lh

def drake(out, t1, t2):
    img = Image.open(os.path.join(HERE, 'templates/drake.jpg')).convert('RGB')
    d = ImageDraw.Draw(img)
    f = load_font(46)
    cx = (575 + 1175) / 2
    draw_wrapped(d, t1, cx, 290, 21, f)
    draw_wrapped(d, t2, cx, 880, 21, f)
    img.save(out, quality=90)

def gru(out, t1, t2, t3, t4):
    # 700x449, 2x2 panels, text on the board (right side of each panel)
    img = Image.open(os.path.join(HERE, 'templates/gru.jpg')).convert('RGB')
    d = ImageDraw.Draw(img)
    f = load_font(22)
    spots = [(272, 130), (622, 130), (272, 345), (622, 345)]
    for text, (cx, cy) in zip([t1, t2, t3, t4], spots):
        draw_wrapped(d, text, cx, cy, 12, f)
    img.save(out, quality=90)

def anakin(out, t1, t2, t3):
    # 768x768, 2x2 panels; text bottom of TL, TR, BR (BL has no text)
    img = Image.open(os.path.join(HERE, 'templates/anakin.png')).convert('RGB')
    d = ImageDraw.Draw(img)
    f = load_font(34)
    spots = [(192, 330), (576, 330), (576, 715)]
    for text, (cx, cy) in zip([t1, t2, t3], spots):
        draw_wrapped(d, text, cx, cy, 20, f, fill='white', stroke=2, stroke_fill='black')
    img.save(out, quality=90)

def uno(out, t1, t2):
    # 500x494; card text upper-left area, label top-right
    img = Image.open(os.path.join(HERE, 'templates/uno.jpg')).convert('RGB')
    d = ImageDraw.Draw(img)
    draw_wrapped(d, t1, 140, 155, 14, load_font(19))
    draw_wrapped(d, t2, 375, 35, 16, load_font(30))
    img.save(out, quality=90)

def fine(out, t1):
    # 580x282; single text block top of LEFT panel, right panel bubble
    # already says "THIS IS FINE"
    img = Image.open(os.path.join(HERE, 'templates/this-is-fine.jpg')).convert('RGB')
    d = ImageDraw.Draw(img)
    f = load_font(24)
    draw_wrapped(d, t1, 145, 48, 20, f, fill='black', stroke=2, stroke_fill='white')
    img.save(out, quality=90)

def topbottom(out, t1, t2, template=None):
    path = template or os.path.join(HERE, 'templates/skeleton.jpg')
    img = Image.open(path).convert('RGB')
    d = ImageDraw.Draw(img)
    W, H = img.size
    f = load_font(max(28, W // 16))
    max_chars = max(14, W // (f.size // 2) // 2)
    draw_wrapped(d, t1.upper(), W / 2, int(H * 0.09), max_chars, f,
                 fill='white', stroke=3, stroke_fill='black')
    draw_wrapped(d, t2.upper(), W / 2, int(H * 0.88), max_chars, f,
                 fill='white', stroke=3, stroke_fill='black')
    img.save(out, quality=90)

if __name__ == '__main__':
    layout, out, *texts = sys.argv[1], sys.argv[2], *sys.argv[3:]
    if layout == 'drake':
        drake(out, texts[0], texts[1])
    elif layout == 'gru':
        gru(out, texts[0], texts[1], texts[2], texts[3])
    elif layout == 'anakin':
        anakin(out, texts[0], texts[1], texts[2])
    elif layout == 'uno':
        uno(out, texts[0], texts[1])
    elif layout == 'fine':
        fine(out, texts[0])
    elif layout == 'topbottom':
        tpl = texts[2] if len(texts) > 2 else None
        topbottom(out, texts[0], texts[1], tpl)
    else:
        sys.exit(f'unknown layout {layout}')
    print(f'saved {out}')
