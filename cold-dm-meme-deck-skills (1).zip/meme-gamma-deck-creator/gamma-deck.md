# Gamma Meme Deck — tested workflow

This is the configuration verified working end to end (meme generated,
hosted, embedded, deck rendered). Follow it exactly.

## Step 1 — Host the meme

```
curl -s -F "files[]=@<meme path>" "https://uguu.se/upload?output=json"
```

Parse `files[0].url`. Then VERIFY it serves a real image:

```
curl -s -o /tmp/v.jpg -w "%{http_code}" "<url>" && file /tmp/v.jpg
```

Must return 200 and `file` must say JPEG or PNG image data. If it says
HTML, the host is wrapping the file — do not use that URL.

Known-good: uguu.se (expires ~24h — fine, Gamma copies the image at
generation time; generate immediately after hosting).
Known-bad (tested, do not use): catbox.moe ("Invalid uploader" from this
environment), litterbox (500s), tmpfiles.org (serves an HTML wrapper, not
the image), 0x0.st (connection reset).
If uguu fails, try `curl -F "file=@<path>" https://x0.at` and verify the
same way. If nothing hosts, deliver the meme file alone and say the deck
needs a reachable image URL.

## Step 2 — Generate the deck

Use the Gamma connector's generate with:
- `cardSplit: inputTextBreaks` and `---` separators (this forces the
  5-slide structure; numCards is ignored in this mode, that is expected)
- `textOptions: { amount: "brief", tone: "direct, dry, founder-to-founder" }`

Slide structure (proven):

```
Slide 1 — Their problem
[Their name], you built [what they built].
Now comes the harder part: [their actual GTM gap, from their profile].
[One line tying company size/stage to the pain.]

---

Slide 2 — The window they're in
[Who is buying what they sell right now, and the visible signals:
new leadership, hiring, public complaints.]
Most founders never look. The ones who do get in the room first.

---

Slide 3 — We had to meme it
Place this image large and centered on this slide: <HOSTED MEME URL>
One line under the image: this is the whole strategy in one image.

---

Slide 4 — The roadmap for [Company]
Step 1: [specific to them]
Step 2: [specific to them]
Step 3: [specific to them]

---

Slide 5 — What working together looks like
[Sender's offer in 2 lines + one proof point + soft ask with their name.]
```

Rules baked into the prompt text you send Gamma:
- Open the inputText with one framing paragraph: who the deck is FOR,
  their company, size, founded year, what they sell, the tone. State
  "This deck is about [their] situation, not about the sender."
- The image line must be literal: "Place this image large and centered on
  this slide: <url>". Gamma fetches and embeds it.
- Sender appears ONLY on slide 5.

## Step 3 — Deliver

Share the gammaUrl. Tell the user to confirm the meme slide rendered —
image fetching is the one external dependency. If it dropped, rehost
(fresh URL) and regenerate; do not retry the same dead URL.

## Placement logic (why slide 3)

The meme sits between problem and roadmap: the exact point where a busy
reader starts skimming. It resets attention and earns the roadmap a read.
Do not open with the meme (reads unserious) and do not close with it
(steps on the ask).
