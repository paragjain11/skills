---
name: meme-gamma-deck-creator
description: |
  Create outreach memes and meme-embedded Gamma decks from a single prompt.
  Two modes: (1) FOLLOW-UP MEME — prospect went quiet, generate a situation-
  matched meme (opened but no reply, not opened yet, replied then went cold,
  no-show on a booked call) ready to send via OutWink or DM. (2) MEME DECK —
  build a personalized Gamma deck for an account with the meme embedded as a
  slide. Triggers: "make a follow-up meme", "meme this ghoster", "they opened
  but never replied, meme them", "no-show meme", "build a meme deck for
  [company]", "meme gamma deck for [prospect]". Requires the Gamma connector
  ON for deck mode. Meme generation is fully local — no Imgflip account needed.
---

# Meme Gamma Deck Creator

Turn a prospect situation into a meme, or a meme plus a personalized Gamma
deck. Everything here is tested: the generator script, the layouts, the
hosting step, and the Gamma prompt structure.

## What's in this folder

- `make_meme.py` — local meme generator. Tested layouts: drake, gru, anakin,
  uno, topbottom (generic, works on any image).
- `templates/` — blank template images the script uses.
- `formats.md` — the caption prompt library: which format fits which
  situation, with fill-in-the-blank prompts modeled on the proven bank.
- `reference-library/` — 34 proven outreach memes organized by situation.
  VIEW 2-3 from the matching folder before writing captions to calibrate tone.
- `gamma-deck.md` — the exact Gamma deck workflow (hosting + prompt structure).

## Mode 1 — Follow-up meme

Input needed: the situation (which of the 4 folders) + anything known about
the prospect (name, company, what they did: "opened 6 times", "said let's
connect soon then vanished", "no-showed Tuesday's call").

1. Identify the situation folder:
   - Opened but No Reply — they saw it, silence
   - Not Opened yet — message sitting unread
   - Replied Then Went Cold — engaged, then vanished
   - No one Showed up at the call — booked, ghosted the meeting
2. View 2-3 reference memes from that folder in `reference-library/` to
   calibrate tone. The bar: gentle self-aware ribbing the prospect would
   screenshot, never mockery.
3. Pick a format from `formats.md` for that situation. Prefer one that fits
   the SPECIFIC detail (e.g. "opened 6 times" → Gru's Plan repetition joke;
   "they'll reply right?" energy → Anakin).
4. Fill the caption prompt from `formats.md`. Swap in the prospect's real
   detail wherever the prompt has a [blank]. Real detail beats clever every
   time. Keep each text slot short — the script wraps text but memes are
   read in one second.
5. Generate:
   `python3 make_meme.py <layout> /mnt/user-data/outputs/<name>-meme.jpg "text1" "text2" [...]`
6. VIEW the output. If text overlaps art or clips, shorten the caption and
   regenerate. Never deliver unviewed.
7. Present the file.

## Mode 2 — Meme deck (meme embedded in a Gamma deck)

Everything in Mode 1, plus:

8. Host the meme so Gamma can fetch it:
   `curl -s -F "files[]=@/mnt/user-data/outputs/<name>-meme.jpg" "https://uguu.se/upload?output=json"`
   Parse `files[0].url` from the JSON. Verify it serves an image
   (`curl -s -o /tmp/v.jpg -w "%{http_code}" <url>` then `file /tmp/v.jpg`
   must say JPEG/PNG). If uguu fails, see fallbacks in `gamma-deck.md`.
   NOTE: uguu links expire in ~24h. Gamma copies the image into the deck at
   generation time, so generate the deck immediately after hosting.
9. Build the deck with the Gamma connector, following the slide structure
   and prompt format in `gamma-deck.md` exactly — it is the tested-working
   configuration. The meme goes on its own slide between the problem and
   the roadmap.
10. Share the gammaUrl. Tell the user to check the meme slide rendered —
    that is the one step with an external dependency.

## Rules

- Never deliver a meme without viewing it first.
- Punch at the situation, never at the person. "Prospects" as a collective
  is fair game; a named person gets the gentlest version.
- One meme per touch. The meme deck is a first-touch or mid-thread move;
  the standalone meme is the follow-up move. Never both with the same image.
- If the user's situation doesn't fit the 4 folders, use the closest
  format from `formats.md` and say which folder logic you borrowed.
- If Gamma connector is off in deck mode, say so and deliver the meme alone.
